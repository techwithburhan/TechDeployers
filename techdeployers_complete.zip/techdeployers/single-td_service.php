<?php
/**
 * /services/{slug}/ (ServiceDetailPage.tsx).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$id    = get_the_ID();
	$color = get_post_meta( $id, '_td_color', true );
	$icon  = get_post_meta( $id, '_td_icon', true );
	$plans = array_filter( (array) get_post_meta( $id, '_td_pricing', true ), function ( $p ) { return is_array( $p ) && ! empty( $p['name'] ); } );
	$box   = 'rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm';
	?>
	<div class="min-h-screen bg-slate-50 text-slate-900">
		<section class="relative isolate overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 pt-24 pb-16 md:pt-32 md:pb-24">
			<?php get_template_part( 'template-parts/components/dark-bg', null, array( 'id' => 'td-sd-grid', 'blobs' => 'animated' ) ); ?>
			<div class="pointer-events-none absolute inset-0 -z-10 hidden md:block" aria-hidden="true">
				<span class="td-spark absolute left-[8%] top-[20%] text-blue-300/60"><?php td_icon( 'sparkles', 18 ); ?></span>
				<span class="td-spark td-d2 absolute left-[20%] top-[70%] text-purple-300/60"><?php td_icon( 'star', 14 ); ?></span>
				<span class="td-spark td-d1 absolute right-[10%] top-[28%] text-cyan-300/60"><?php td_icon( 'sparkles', 20 ); ?></span>
				<span class="td-spark td-d3 absolute right-[28%] top-[78%] text-pink-300/60"><?php td_icon( 'star', 12 ); ?></span>
				<span class="td-spark td-d2 absolute left-[42%] top-[15%] text-yellow-300/60"><?php td_icon( 'zap', 16 ); ?></span>
				<span class="td-spark td-d1 absolute right-[40%] bottom-[18%] text-blue-300/60"><?php td_icon( 'sparkles', 14 ); ?></span>
			</div>

			<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
				<a href="<?php echo esc_url( td_services_url() ); ?>" class="td-fade-down mb-8 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium text-white/90 backdrop-blur-md transition hover:bg-white/15 hover:text-white">
					<?php td_icon( 'arrow-left', 16 ); ?> <?php esc_html_e( 'Back to Services', 'techdeployers' ); ?>
				</a>

				<div class="grid items-center gap-10 lg:grid-cols-[1.2fr_0.8fr]">
					<div>
						<?php if ( td_opt( 'sd_tag' ) ) : ?>
							<div class="td-fade-up mb-5 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm text-white"><?php td_icon( 'rocket', 15, 'text-blue-300' ); ?> <?php td_e( 'sd_tag' ); ?></div>
						<?php endif; ?>
						<h1 class="td-fade-up td-delay-1 mb-6 text-4xl font-extrabold leading-tight text-white md:text-6xl"><?php the_title(); ?></h1>
						<p class="td-fade-up td-delay-2 max-w-3xl text-base leading-8 text-slate-300 md:text-lg"><?php echo esc_html( get_post_meta( $id, '_td_hero_desc', true ) ); ?></p>
						<div class="mt-8 flex flex-wrap gap-3">
							<?php foreach ( td_list( get_post_meta( $id, '_td_features', true ) ) as $i => $feature ) : ?>
								<span class="td-pop rounded-full border border-white/20 bg-white/5 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/10" style="animation-delay:<?php echo esc_attr( 0.6 + $i * 0.08 ); ?>s"><?php echo esc_html( $feature ); ?></span>
							<?php endforeach; ?>
						</div>
					</div>

					<div class="relative">
						<div class="pointer-events-none absolute inset-0 hidden sm:flex items-center justify-center" aria-hidden="true">
							<div class="td-orbit relative h-[360px] w-[360px] rounded-full border border-dashed border-white/10">
								<div class="td-orbit-icon absolute -top-3 left-1/2 -ml-4 rounded-xl border border-white/15 bg-white/10 p-2 backdrop-blur-md"><?php td_icon( 'zap', 16, 'text-yellow-300' ); ?></div>
								<div class="td-orbit-icon absolute -bottom-3 left-1/2 -ml-4 rounded-xl border border-white/15 bg-white/10 p-2 backdrop-blur-md"><?php td_icon( 'star', 16, 'text-pink-300' ); ?></div>
							</div>
							<div class="td-orbit td-orbit-rev absolute h-[280px] w-[280px] rounded-full border border-dashed border-white/10">
								<div class="td-orbit-icon absolute top-1/2 -left-3 -mt-4 rounded-xl border border-white/15 bg-white/10 p-2 backdrop-blur-md"><?php td_icon( 'cpu', 16, 'text-blue-300' ); ?></div>
								<div class="td-orbit-icon absolute top-1/2 -right-3 -mt-4 rounded-xl border border-white/15 bg-white/10 p-2 backdrop-blur-md"><?php td_icon( 'earth', 16, 'text-cyan-300' ); ?></div>
							</div>
						</div>

						<div class="td-tilt td-slide-in relative rounded-[2rem] border border-white/10 bg-white/10 p-6 md:p-8 shadow-2xl backdrop-blur-xl">
							<div class="relative mx-auto h-28 w-28">
								<div class="td-glow absolute inset-0 rounded-3xl <?php echo esc_attr( td_color( $color, 'soft' ) ); ?> opacity-50 blur-2xl"></div>
								<div class="td-icon-float relative mx-auto flex h-28 w-28 items-center justify-center rounded-3xl <?php echo esc_attr( td_color( $color, 'soft' ) . ' ' . td_color( $color, 'icon' ) ); ?> shadow-xl ring-1 ring-white/40">
									<?php td_icon( $icon, 50 ); ?>
								</div>
							</div>
							<div class="mt-8 space-y-4">
								<div class="rounded-2xl border border-white/10 bg-slate-900/50 p-5 text-white/90 transition hover:border-blue-400/40 hover:bg-slate-900/70">
									<div class="flex items-center gap-2 text-sm text-slate-400"><?php td_icon( 'sparkles', 14, 'text-blue-300' ); ?> <?php td_e( 'sd_card1_label' ); ?></div>
									<div class="mt-1 text-lg font-semibold"><?php td_e( 'sd_card1_text' ); ?></div>
								</div>
								<div class="rounded-2xl border border-white/10 bg-slate-900/50 p-5 text-white/90 transition hover:border-purple-400/40 hover:bg-slate-900/70">
									<div class="flex items-center gap-2 text-sm text-slate-400"><?php td_icon( 'rocket', 14, 'text-purple-300' ); ?> <?php td_e( 'sd_card2_label' ); ?></div>
									<div class="mt-1 text-lg font-semibold"><?php td_e( 'sd_card2_text' ); ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:py-20 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
			<div class="space-y-8">
				<?php if ( trim( get_the_content() ) ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<div class="mb-4 flex items-center gap-3"><?php td_icon( 'badge-check', 22, 'text-blue-600' ); ?><h2 class="text-2xl font-bold"><?php esc_html_e( 'Service Overview', 'techdeployers' ); ?></h2></div>
						<div class="td-prose td-prose-plain text-base leading-8 text-slate-600"><?php the_content(); ?></div>
					</div>
				<?php endif; ?>

				<?php $deliverables = td_list( get_post_meta( $id, '_td_deliverables', true ) ); if ( $deliverables ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<div class="mb-5 flex items-center gap-3"><?php td_icon( 'layers', 22, 'text-blue-600' ); ?><h2 class="text-2xl font-bold"><?php esc_html_e( 'What You Get', 'techdeployers' ); ?></h2></div>
						<div class="grid gap-4 md:grid-cols-2">
							<?php foreach ( $deliverables as $item ) : ?><div class="rounded-2xl bg-slate-50 p-4 text-sm font-medium text-slate-700"><?php echo esc_html( $item ); ?></div><?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php $process = td_list( get_post_meta( $id, '_td_process', true ) ); if ( $process ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<div class="mb-5 flex items-center gap-3"><?php td_icon( 'wrench', 22, 'text-blue-600' ); ?><h2 class="text-2xl font-bold"><?php esc_html_e( 'Our Process', 'techdeployers' ); ?></h2></div>
						<ol class="space-y-4">
							<?php foreach ( $process as $i => $step ) : ?>
								<li class="flex gap-4 rounded-2xl bg-slate-50 p-4">
									<span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-600 text-sm font-bold text-white"><?php echo (int) $i + 1; ?></span>
									<span class="pt-2 text-slate-700"><?php echo esc_html( $step ); ?></span>
								</li>
							<?php endforeach; ?>
						</ol>
					</div>
				<?php endif; ?>
			</div>

			<div class="space-y-8">
				<?php $benefits = td_list( get_post_meta( $id, '_td_benefits', true ) ); if ( $benefits ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<div class="mb-5 flex items-center gap-3"><?php td_icon( 'circle-check', 22, 'text-blue-600' ); ?><h2 class="text-2xl font-bold"><?php esc_html_e( 'Key Benefits', 'techdeployers' ); ?></h2></div>
						<div class="space-y-4">
							<?php foreach ( $benefits as $b ) : ?>
								<div class="flex gap-3"><?php td_icon( 'circle-check', 18, 'mt-0.5 shrink-0 text-blue-600' ); ?><p class="text-slate-600"><?php echo esc_html( $b ); ?></p></div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php $ideal = td_list( get_post_meta( $id, '_td_ideal_for', true ) ); if ( $ideal ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<div class="mb-5 flex items-center gap-3"><?php td_icon( 'briefcase', 22, 'text-blue-600' ); ?><h2 class="text-2xl font-bold"><?php esc_html_e( 'Ideal For', 'techdeployers' ); ?></h2></div>
						<div class="space-y-3">
							<?php foreach ( $ideal as $item ) : ?><div class="rounded-2xl bg-slate-50 px-4 py-3 text-slate-700"><?php echo esc_html( $item ); ?></div><?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php $tech = td_list( get_post_meta( $id, '_td_technologies', true ) ); if ( $tech ) : ?>
					<div class="td-reveal <?php echo esc_attr( $box ); ?>">
						<h2 class="mb-5 text-2xl font-bold"><?php esc_html_e( 'Technologies & Tools', 'techdeployers' ); ?></h2>
						<div class="flex flex-wrap gap-3">
							<?php foreach ( $tech as $t ) : ?><span class="rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700"><?php echo esc_html( $t ); ?></span><?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</section>

		<?php if ( $plans ) : ?>
			<section class="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
				<div class="td-reveal mx-auto mb-12 max-w-3xl text-center">
					<?php if ( td_opt( 'price_badge' ) ) : ?>
						<div class="mb-4 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-sm font-bold uppercase tracking-wider text-blue-700"><?php td_icon( 'tag', 14 ); ?> <?php td_e( 'price_badge' ); ?></div>
					<?php endif; ?>
					<h2 class="mb-4 text-3xl font-bold text-slate-900 md:text-5xl"><?php td_e( 'price_title' ); ?></h2>
					<p class="text-base text-slate-600 md:text-lg"><?php td_e( 'price_text' ); ?></p>
				</div>

				<div class="grid gap-6 pt-6 md:grid-cols-2 <?php echo count( $plans ) >= 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'; ?>">
					<?php
					foreach ( $plans as $plan ) :
						$hi = ! empty( $plan['highlighted'] );
						?>
						<div class="td-reveal relative flex flex-col rounded-3xl border p-6 md:p-8 transition-transform duration-300 hover:-translate-y-2 hover:shadow-2xl <?php echo $hi ? 'z-10 border-blue-600 bg-white shadow-xl shadow-blue-600/10 lg:-mt-4 lg:scale-105' : 'border-slate-200 bg-white shadow-sm'; ?>">
							<?php if ( $hi && td_opt( 'price_popular' ) ) : ?>
								<div class="mb-6 self-start"><div class="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-blue-700"><?php td_icon( 'rocket', 14, 'text-blue-600' ); ?> <?php td_e( 'price_popular' ); ?></div></div>
							<?php endif; ?>
							<div class="mb-6">
								<h3 class="mb-2 text-xl font-bold text-slate-900"><?php echo esc_html( $plan['name'] ); ?></h3>
								<p class="text-sm text-slate-600"><?php echo esc_html( $plan['desc'] ); ?></p>
							</div>
							<div class="mb-6 flex flex-wrap items-baseline gap-2">
								<span class="text-4xl font-extrabold text-slate-900 md:text-5xl"><?php echo esc_html( $plan['price'] ); ?></span>
								<?php if ( $plan['note'] ) : ?><span class="text-sm text-slate-500"><?php echo esc_html( $plan['note'] ); ?></span><?php endif; ?>
							</div>
							<div class="mb-6 h-px w-full bg-slate-200"></div>
							<ul class="mb-8 flex-1 space-y-3">
								<?php foreach ( td_list( $plan['features'] ) as $f ) : ?>
									<li class="flex items-start gap-3"><?php td_icon( 'circle-check', 18, 'mt-0.5 shrink-0 text-blue-600' ); ?><span class="text-sm text-slate-700"><?php echo esc_html( $f ); ?></span></li>
								<?php endforeach; ?>
							</ul>
							<a href="<?php echo esc_url( add_query_arg( 'service', rawurlencode( get_the_title() . ' – ' . $plan['name'] ), td_contact_url() ) ); ?>" class="inline-flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition-all duration-300 <?php echo $hi ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-600/20' : 'bg-slate-900 text-white hover:bg-blue-600'; ?>">
								<?php echo esc_html( $plan['cta'] ? $plan['cta'] : __( 'Get Started', 'techdeployers' ) ); ?> <?php td_icon( 'arrow-right', 16 ); ?>
							</a>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="td-reveal mx-auto mt-12 max-w-3xl rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-sm md:p-8">
					<p class="text-sm text-slate-600 md:text-base"><span class="font-bold text-slate-900"><?php esc_html_e( 'Need a custom plan?', 'techdeployers' ); ?></span> <?php td_e( 'price_custom' ); ?></p>
					<a href="<?php echo esc_url( td_contact_url() ); ?>" class="mt-4 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-6 py-3 text-sm font-bold text-white transition hover:bg-blue-700 hover:shadow-lg"><?php td_e( 'price_custom_btn' ); ?> <?php td_icon( 'arrow-right', 16 ); ?></a>
				</div>
			</section>
		<?php endif; ?>
	</div>
	<?php
endwhile;
get_footer();
