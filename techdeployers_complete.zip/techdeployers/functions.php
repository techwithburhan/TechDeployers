<?php
/**
 * TechDeployers theme bootstrap.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'TD_VERSION', '1.0.0' );
define( 'TD_DIR', get_template_directory() );
define( 'TD_URI', get_template_directory_uri() );

require TD_DIR . '/inc/icons.php';
require TD_DIR . '/inc/helpers.php';
require TD_DIR . '/inc/customizer.php';
require TD_DIR . '/inc/post-types.php';
require TD_DIR . '/inc/meta-boxes.php';
require TD_DIR . '/inc/term-meta.php';
require TD_DIR . '/inc/forms.php';
require TD_DIR . '/inc/demo-data.php';
require TD_DIR . '/inc/admin.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'techdeployers', TD_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 48, 'width' => 200, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );

	register_nav_menus( array(
		'primary'         => __( 'Main menu (header)', 'techdeployers' ),
		'footer_services' => __( 'Footer – Services column', 'techdeployers' ),
		'footer_company'  => __( 'Footer – Company column', 'techdeployers' ),
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	$css = TD_DIR . '/assets/css/main.css';
	$js  = TD_DIR . '/assets/js/main.js';
	wp_enqueue_style( 'td-main', TD_URI . '/assets/css/main.css', array(), file_exists( $css ) ? filemtime( $css ) : TD_VERSION );
	wp_enqueue_script( 'td-main', TD_URI . '/assets/js/main.js', array(), file_exists( $js ) ? filemtime( $js ) : TD_VERSION, true );
} );

/* Body classes used by the header to know whether the page starts with a dark hero. */
add_filter( 'body_class', function ( $classes ) {
	$classes[] = 'bg-slate-50';
	return $classes;
} );

/* Nicer excerpt length for cards. */
add_filter( 'excerpt_length', function () { return 30; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/* Keep the blog grid in date order (sticky posts are shown separately as "Featured"). */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && $q->is_home() ) {
		$q->set( 'ignore_sticky_posts', true );
	}
} );

/* Mark JS as available before first paint (prevents a flash of reveal-animated content). */
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('td-js');</script>\n";
}, 1 );
