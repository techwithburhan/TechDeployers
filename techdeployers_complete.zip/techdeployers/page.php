<?php
/**
 * Generic page (Privacy Policy, Terms, etc.) styled to match the site.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<section class="relative isolate bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 pt-32 pb-16 overflow-hidden">
		<?php get_template_part( 'template-parts/components/dark-bg', null, array( 'id' => 'td-page-grid' ) ); ?>
		<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
			<h1 class="td-fade-up text-4xl md:text-6xl font-extrabold text-white leading-tight"><?php the_title(); ?></h1>
		</div>
	</section>
	<div class="bg-white">
		<div class="td-prose max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16"><?php the_content(); ?></div>
	</div>
	<?php
endwhile;
get_footer();
