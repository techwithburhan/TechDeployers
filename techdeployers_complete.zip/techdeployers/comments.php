<?php
/**
 * Comments (only shown when comments are open on a post).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="pt-10 border-t border-slate-200">
	<?php if ( have_comments() ) : ?>
		<h2>
			<?php
			/* translators: %s: number of comments */
			printf( esc_html( _n( '%s Comment', '%s Comments', get_comments_number(), 'techdeployers' ) ), esc_html( number_format_i18n( get_comments_number() ) ) );
			?>
		</h2>
		<ol class="comment-list" style="list-style:none;padding:0">
			<?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 40 ) ); ?>
		</ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>
	<?php if ( comments_open() ) : ?>
		<?php comment_form( array( 'class_submit' => 'submit' ) ); ?>
	<?php endif; ?>
</section>
