<?php
/**
 * Template Name: About (TechDeployers)
 *
 * About.tsx. Paragraphs = this page's content. Everything else: Customize → TechDeployers → About Page.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$img = has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'large' ) : td_opt( 'about_image' );
	?>
	<div class="pt-24 pb-24 bg-white">
		<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
			<div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
				<div class="td-reveal relative">
					<div class="aspect-square rounded-[3rem] bg-blue-100 overflow-hidden">
						<?php if ( $img ) : ?><img src="<?php echo esc_url( $img ); ?>" alt="<?php esc_attr_e( 'Our Team', 'techdeployers' ); ?>" class="w-full h-full object-cover mix-blend-multiply opacity-80"><?php endif; ?>
					</div>
					<?php if ( td_opt( 'about_years' ) ) : ?>
						<div class="absolute -bottom-6 right-0 sm:-right-6 bg-white p-6 sm:p-8 rounded-3xl shadow-2xl border border-slate-100">
							<p class="text-4xl font-bold text-blue-600"><?php td_e( 'about_years' ); ?></p>
							<p class="text-slate-600 font-medium"><?php td_e( 'about_years_label' ); ?></p>
						</div>
					<?php endif; ?>
				</div>
				<div class="td-reveal space-y-8">
					<?php if ( td_opt( 'about_badge' ) ) : ?><h2 class="text-blue-600 font-bold tracking-wider uppercase text-sm"><?php td_e( 'about_badge' ); ?></h2><?php endif; ?>
					<h1 class="text-4xl md:text-5xl font-bold text-slate-900"><?php echo esc_html( td_opt( 'about_title' ) ? td_opt( 'about_title' ) : get_the_title() ); ?></h1>
					<div class="td-prose td-prose-plain text-lg text-slate-600 leading-relaxed"><?php the_content(); ?></div>
					<?php $check = td_list( td_opt( 'about_checklist' ) ); if ( $check ) : ?>
						<div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
							<?php foreach ( $check as $item ) : ?>
								<div class="flex items-center space-x-2"><?php td_icon( 'circle-check', 20, 'text-blue-600 shrink-0' ); ?><span class="font-semibold text-slate-700"><?php echo esc_html( $item ); ?></span></div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php $values = td_lines( td_opt( 'about_values' ), 3 ); if ( $values ) : ?>
				<div class="td-reveal text-center mb-20">
					<h2 class="text-3xl md:text-4xl font-bold text-slate-900 mb-4"><?php td_e( 'about_values_title' ); ?></h2>
					<p class="text-lg text-slate-600 max-w-2xl mx-auto"><?php td_e( 'about_values_text' ); ?></p>
				</div>
				<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
					<?php foreach ( $values as $v ) : ?>
						<div class="td-reveal p-8 bg-slate-50 rounded-3xl hover:bg-white hover:shadow-xl hover:-translate-y-2 transition-all duration-300 border border-transparent hover:border-slate-100">
							<div class="mb-6 inline-block p-4 bg-white rounded-2xl shadow-sm"><?php td_icon( $v[0], 32, 'text-blue-600' ); ?></div>
							<h3 class="text-xl font-bold text-slate-900 mb-4"><?php echo esc_html( $v[1] ); ?></h3>
							<p class="text-slate-600 leading-relaxed"><?php echo esc_html( $v[2] ); ?></p>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
endwhile;
get_footer();
