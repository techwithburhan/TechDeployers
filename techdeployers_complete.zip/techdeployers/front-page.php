<?php
/**
 * Home page (Home.tsx). Every section can be edited / hidden in
 * Appearance → Customize → TechDeployers.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<div class="bg-white text-slate-900 overflow-hidden">
	<?php
	get_template_part( 'template-parts/home/hero' );
	if ( td_opt( 'show_testimonials' ) ) {
		get_template_part( 'template-parts/home/testimonials' );
	}
	if ( td_opt( 'show_capabilities' ) ) {
		get_template_part( 'template-parts/home/capabilities' );
	}
	if ( td_opt( 'show_why' ) ) {
		get_template_part( 'template-parts/home/why' );
	}
	if ( td_opt( 'show_home_blog' ) ) {
		get_template_part( 'template-parts/home/latest-posts' );
	}
	if ( td_opt( 'show_home_cta' ) ) {
		get_template_part( 'template-parts/home/cta' );
	}

	// Anything typed into the "Home" page editor is shown at the end (optional).
	while ( is_page() && have_posts() ) :
		the_post();
		if ( trim( get_the_content() ) ) :
			?>
			<section class="py-16 bg-white"><div class="td-prose max-w-4xl mx-auto px-4"><?php the_content(); ?></div></section>
			<?php
		endif;
	endwhile;
	?>
</div>
<?php
get_footer();
