<?php
/**
 * Blog article (BlogDetailPage.tsx).
 * Write the article normally in the editor: H2 headings are numbered and bullet lists get check marks automatically.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$cat    = td_post_category();
	$author = td_post_author();
	$read   = td_read_time();
	$date   = get_the_date();
	$tags   = get_the_tags();
	$bio    = get_the_author_meta( 'description' ) ? get_the_author_meta( 'description' ) : td_opt( 'p_author_bio' );
	?>
	<div class="min-h-screen bg-slate-50">
		<section class="relative isolate bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 pt-28 pb-16 overflow-hidden">
			<?php get_template_part( 'template-parts/components/dark-bg', null, array( 'id' => 'td-post-grid' ) ); ?>
			<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
				<a href="<?php echo esc_url( td_blog_url() ); ?>" class="td-fade-down mb-8 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium text-white/90 backdrop-blur-md hover:bg-white/20 transition-all">
					<?php td_icon( 'arrow-left', 16 ); ?> <?php esc_html_e( 'Back to Blog', 'techdeployers' ); ?>
				</a>
				<?php if ( $cat['name'] ) : ?>
					<div><a href="<?php echo esc_url( $cat['link'] ); ?>" class="td-fade-up inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold mb-5 <?php echo esc_attr( $cat['class'] ); ?>"><?php td_icon( 'tag', 11 ); ?><?php echo esc_html( $cat['name'] ); ?></a></div>
				<?php endif; ?>
				<h1 class="td-fade-up td-delay-1 text-3xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6"><?php the_title(); ?></h1>
				<div class="td-fade-up td-delay-2 flex flex-wrap items-center gap-4 md:gap-6">
					<div class="flex items-center gap-3">
						<div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-sm"><?php echo esc_html( $author['initials'] ); ?></div>
						<div>
							<p class="text-white font-semibold text-sm"><?php echo esc_html( $author['name'] ); ?></p>
							<?php if ( $author['role'] ) : ?><p class="text-slate-400 text-xs"><?php echo esc_html( $author['role'] ); ?></p><?php endif; ?>
						</div>
					</div>
					<div class="flex items-center gap-1 text-slate-400 text-sm"><?php td_icon( 'calendar', 14 ); ?><?php echo esc_html( $date ); ?></div>
					<div class="flex items-center gap-1 text-slate-400 text-sm"><?php td_icon( 'clock', 14 ); ?><?php echo esc_html( $read ); ?></div>
				</div>
			</div>
		</section>

		<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
			<div class="td-zoom-in rounded-3xl overflow-hidden shadow-2xl">
				<img src="<?php echo esc_url( td_cover_url( null, 'full' ) ); ?>" alt="<?php the_title_attribute(); ?>" class="w-full h-64 md:h-96 object-cover">
			</div>
		</div>

		<article class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
			<div class="grid lg:grid-cols-[1fr_280px] gap-12">
				<div class="space-y-10 min-w-0">
					<?php if ( has_excerpt() ) : ?>
						<div class="td-reveal p-6 rounded-2xl bg-blue-50 border-l-4 border-blue-600">
							<p class="text-blue-900 text-lg leading-relaxed font-medium italic"><?php echo esc_html( get_the_excerpt() ); ?></p>
						</div>
					<?php endif; ?>

					<div class="td-prose td-article">
						<?php the_content(); ?>
						<?php wp_link_pages(); ?>
					</div>

					<?php if ( $tags ) : ?>
						<div class="td-reveal pt-6 border-t border-slate-200">
							<p class="text-sm font-semibold text-slate-500 mb-3"><?php esc_html_e( 'Tags', 'techdeployers' ); ?></p>
							<div class="flex flex-wrap gap-2">
								<?php foreach ( $tags as $tag ) : ?>
									<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>" class="px-3 py-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 text-sm rounded-xl font-medium transition-colors">#<?php echo esc_html( $tag->name ); ?></a>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( comments_open() || get_comments_number() ) : ?>
						<div class="td-prose"><?php comments_template(); ?></div>
					<?php endif; ?>
				</div>

				<aside class="space-y-6">
					<div class="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 lg:sticky lg:top-24">
						<h3 class="font-bold text-slate-900 mb-4 text-sm uppercase tracking-wider"><?php esc_html_e( 'About the Author', 'techdeployers' ); ?></h3>
						<div class="flex items-center gap-3 mb-4">
							<div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg"><?php echo esc_html( $author['initials'] ); ?></div>
							<div>
								<p class="font-bold text-slate-900"><?php echo esc_html( $author['name'] ); ?></p>
								<?php if ( $author['role'] ) : ?><p class="text-sm text-slate-500"><?php echo esc_html( $author['role'] ); ?></p><?php endif; ?>
							</div>
						</div>
						<p class="text-sm text-slate-600 leading-relaxed"><?php echo esc_html( $bio ); ?></p>
						<div class="mt-6 pt-6 border-t border-slate-100 space-y-3">
							<div class="flex items-center gap-2 text-sm text-slate-600"><?php td_icon( 'calendar', 14, 'text-blue-600' ); ?><span><?php echo esc_html( $date ); ?></span></div>
							<div class="flex items-center gap-2 text-sm text-slate-600"><?php td_icon( 'clock', 14, 'text-blue-600' ); ?><span><?php echo esc_html( $read ); ?></span></div>
							<?php if ( $cat['name'] ) : ?>
								<div class="flex items-center gap-2 text-sm"><?php td_icon( 'tag', 14, 'text-blue-600' ); ?><span class="px-2 py-0.5 rounded-full text-xs font-bold <?php echo esc_attr( $cat['class'] ); ?>"><?php echo esc_html( $cat['name'] ); ?></span></div>
							<?php endif; ?>
						</div>
						<a href="<?php echo esc_url( td_contact_url() ); ?>" class="mt-6 w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all hover:shadow-lg"><?php esc_html_e( 'Work With Us', 'techdeployers' ); ?> <?php td_icon( 'arrow-right', 14 ); ?></a>
					</div>
				</aside>
			</div>
		</article>

		<?php
		$cat_ids = wp_get_post_categories( get_the_ID() );
		$related = new WP_Query( array( 'category__in' => $cat_ids, 'post__not_in' => array( get_the_ID() ), 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) );
		if ( ! $related->have_posts() ) {
			$related = new WP_Query( array( 'post__not_in' => array( get_the_ID() ), 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) );
		}
		if ( $related->have_posts() ) :
			?>
			<section class="bg-white border-t border-slate-100 py-16">
				<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
					<h2 class="text-2xl md:text-3xl font-bold text-slate-900 mb-10 flex items-center gap-3"><span class="w-8 h-1 bg-blue-600 rounded-full inline-block"></span><?php esc_html_e( 'More Articles You Might Like', 'techdeployers' ); ?></h2>
					<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
						<?php
						while ( $related->have_posts() ) :
							$related->the_post();
							get_template_part( 'template-parts/components/post-card', null, array( 'variant' => 'related' ) );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<div class="text-center mt-12">
						<a href="<?php echo esc_url( td_blog_url() ); ?>" class="inline-flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-blue-600 transition-all hover:shadow-xl"><?php esc_html_e( 'View All Articles', 'techdeployers' ); ?> <?php td_icon( 'arrow-right', 18 ); ?></a>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<?php get_template_part( 'template-parts/components/cta-band', null, array( 'title' => td_opt( 'p_cta_title' ), 'text' => td_opt( 'p_cta_text' ) ) ); ?>
	</div>
	<?php
endwhile;
get_footer();
