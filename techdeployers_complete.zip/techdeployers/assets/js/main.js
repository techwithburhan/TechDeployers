/**
 * TechDeployers theme scripts (vanilla JS, no dependencies).
 * Replaces React state + GSAP from the original project.
 */
(function () {
	'use strict';
	var doc = document.documentElement;
	doc.classList.add('td-js');
	var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function ready(fn) {
		if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
	}

	ready(function () {
		/* ---------- Navbar: shadow on scroll + mobile menu ---------- */
		var nav = document.getElementById('td-nav');
		if (nav) {
			var onScroll = function () { nav.classList.toggle('is-scrolled', window.scrollY > 20); };
			window.addEventListener('scroll', onScroll, { passive: true });
			onScroll();
		}
		var btn = document.getElementById('td-menu-btn');
		var menu = document.getElementById('td-mobile-menu');
		if (btn && menu) {
			btn.addEventListener('click', function () {
				var open = menu.classList.toggle('hidden') === false;
				btn.setAttribute('aria-expanded', open ? 'true' : 'false');
				btn.querySelector('.td-icon-open').classList.toggle('hidden', open);
				btn.querySelector('.td-icon-close').classList.toggle('hidden', !open);
			});
			menu.addEventListener('click', function (e) {
				if (e.target.closest('a')) { menu.classList.add('hidden'); btn.setAttribute('aria-expanded', 'false'); }
			});
		}

		/* ---------- Scroll reveal ---------- */
		var reveal = function (el) {
			el.classList.add('is-visible');
			// Hand transitions back to Tailwind once revealed (keeps hover effects smooth).
			setTimeout(function () { el.classList.remove('td-reveal', 'is-visible'); }, 900);
		};
		var items = document.querySelectorAll('.td-reveal');
		if ('IntersectionObserver' in window && !reduceMotion) {
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) { reveal(entry.target); io.unobserve(entry.target); }
				});
			}, { rootMargin: '0px 0px -10% 0px' });
			items.forEach(function (el) {
				// Elements hidden at this screen size (e.g. mobile-only blocks) are shown without animation.
				if (el.offsetParent === null) { el.classList.remove('td-reveal'); return; }
				io.observe(el);
			});
		} else {
			items.forEach(reveal);
		}

		/* ---------- Number counters (Services hero) ---------- */
		var counters = document.querySelectorAll('[data-td-count]');
		var runCounter = function (el, i) {
			var end = parseInt(el.getAttribute('data-td-count'), 10) || 0;
			var suffix = el.getAttribute('data-suffix') || '';
			if (reduceMotion) { el.textContent = end + suffix; return; }
			var start = null, duration = 2000, delay = 500 + i * 150;
			el.textContent = '0' + suffix;
			setTimeout(function () {
				var step = function (ts) {
					if (!start) { start = ts; }
					var p = Math.min((ts - start) / duration, 1);
					var eased = 1 - Math.pow(1 - p, 2);
					el.textContent = Math.round(end * eased) + suffix;
					if (p < 1) { requestAnimationFrame(step); }
				};
				requestAnimationFrame(step);
			}, delay);
		};
		if (counters.length) {
			if ('IntersectionObserver' in window) {
				var cio = new IntersectionObserver(function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							runCounter(entry.target, Array.prototype.indexOf.call(counters, entry.target));
							cio.unobserve(entry.target);
						}
					});
				});
				counters.forEach(function (el) { cio.observe(el); });
			} else {
				counters.forEach(runCounter);
			}
		}

		/* ---------- 3D tilt card (service detail) ---------- */
		document.querySelectorAll('.td-tilt').forEach(function (card) {
			if (reduceMotion || window.matchMedia('(hover: none)').matches) { return; }
			card.addEventListener('mousemove', function (e) {
				var r = card.getBoundingClientRect();
				var ry = ((e.clientX - r.left - r.width / 2) / r.width) * 14;
				var rx = -((e.clientY - r.top - r.height / 2) / r.height) * 14;
				card.style.transform = 'perspective(900px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
			});
			card.addEventListener('mouseleave', function () { card.style.transform = ''; });
		});

		/* ---------- Video testimonials carousel ---------- */
		document.querySelectorAll('.td-testimonials').forEach(function (section) {
			var sources = section.querySelectorAll('template.td-testi-src');
			var total = sources.length;
			if (!total) { return; }
			var active = 0, autoplay = total > 1, timer = null;
			var slots = {};
			section.querySelectorAll('[data-td-slot]').forEach(function (s) { slots[s.getAttribute('data-td-slot')] = s; });
			var dots = section.querySelectorAll('[data-td-dot]');
			var progress = section.querySelector('.td-progress');

			var cardFor = function (index, side) {
				var node = sources[index].content.firstElementChild.cloneNode(true);
				if (side) {
					node.classList.remove('opacity-100', 'scale-100');
					node.classList.add('opacity-50', 'scale-95');
					var play = node.querySelector('.td-play');
					if (play) { play.setAttribute('tabindex', '-1'); play.setAttribute('aria-hidden', 'true'); }
				}
				return node;
			};
			var render = function () {
				var left = (active - 1 + total) % total, right = (active + 1) % total;
				if (slots.left) { slots.left.replaceChildren(cardFor(left, true)); }
				if (slots.center) { slots.center.replaceChildren(cardFor(active, false)); }
				if (slots.right) { slots.right.replaceChildren(cardFor(right, true)); }
				if (slots.mobile) { slots.mobile.replaceChildren(cardFor(active, false)); }
				dots.forEach(function (d, i) {
					var on = i === active;
					d.className = 'td-dot rounded-full transition-all duration-300 ' + (on ? 'w-8 h-2.5 bg-blue-600 shadow-md shadow-blue-200' : 'w-2.5 h-2.5 bg-slate-300 hover:bg-slate-400');
					d.setAttribute('aria-current', on ? 'true' : 'false');
				});
				if (progress) {
					progress.classList.remove('is-running');
					if (autoplay && !reduceMotion) { void progress.offsetWidth; progress.classList.add('is-running'); }
					else { progress.style.width = '0'; }
				}
			};
			var stop = function () {
				autoplay = false;
				if (timer) { clearInterval(timer); timer = null; }
			};
			var go = function (index) { stop(); active = (index + total) % total; render(); };

			section.addEventListener('click', function (e) {
				var play = e.target.closest('.td-play');
				var inSide = e.target.closest('[data-td-slot="left"],[data-td-slot="right"]');
				if (play && !inSide) {
					stop();
					var media = play.closest('.td-vmedia');
					var id = media.getAttribute('data-video');
					var frame = document.createElement('iframe');
					frame.className = 'absolute inset-0 w-full h-full';
					frame.src = 'https://www.youtube.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0&modestbranding=1&controls=1';
					frame.title = media.getAttribute('data-title') + ' testimonial';
					frame.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
					frame.allowFullscreen = true;
					media.replaceChildren(frame);
					return;
				}
				if (e.target.closest('[data-td-prev]')) { go(active - 1); return; }
				if (e.target.closest('[data-td-next]')) { go(active + 1); return; }
				var dot = e.target.closest('[data-td-dot]');
				if (dot) { go(parseInt(dot.getAttribute('data-td-dot'), 10)); }
			});

			render();
			if (autoplay && !reduceMotion) {
				timer = setInterval(function () { if (autoplay) { active = (active + 1) % total; render(); } }, 6000);
			}
		});

		/* ---------- Blog: instant filter while typing (Enter = full search) ---------- */
		var search = document.querySelector('.td-live-search');
		var grid = document.querySelector('.td-post-grid');
		if (search && grid) {
			var cards = grid.querySelectorAll('.td-post-card');
			var empty = document.querySelector('.td-no-results');
			var featured = document.querySelector('.td-featured');
			search.addEventListener('input', function () {
				var q = search.value.trim().toLowerCase(), shown = 0;
				cards.forEach(function (c) {
					var match = !q || (c.getAttribute('data-search') || '').indexOf(q) !== -1;
					c.style.display = match ? '' : 'none';
					if (match) { shown++; }
				});
				if (empty) { empty.classList.toggle('hidden', shown > 0); }
				if (featured) { featured.style.display = q ? 'none' : ''; }
			});
		}
	});
})();
