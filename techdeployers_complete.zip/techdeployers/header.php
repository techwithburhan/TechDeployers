<?php
/**
 * Site header (Navbar.tsx).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$td_links = td_primary_links();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:bg-white focus:px-4 focus:py-2 focus:rounded-lg" href="#td-main"><?php esc_html_e( 'Skip to content', 'techdeployers' ); ?></a>
<div class="min-h-screen flex flex-col bg-slate-50">
	<nav id="td-nav" class="td-nav fixed w-full z-50 transition-all duration-300 backdrop-blur-lg bg-white/70 py-4" aria-label="<?php esc_attr_e( 'Main', 'techdeployers' ); ?>">
		<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
			<div class="flex justify-between items-center">
				<?php td_logo(); ?>

				<div class="hidden md:flex items-center space-x-8">
					<?php foreach ( $td_links as $link ) : ?>
						<a href="<?php echo esc_url( $link['url'] ); ?>"<?php echo ! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : ''; ?> class="font-medium transition-colors <?php echo td_is_current( $link['url'] ) ? 'text-blue-600' : 'text-slate-700 hover:text-blue-600'; ?>"><?php echo esc_html( $link['name'] ); ?></a>
					<?php endforeach; ?>
					<?php if ( td_opt( 'header_cta_text' ) ) : ?>
						<a href="<?php echo esc_url( td_link( td_opt( 'header_cta_url' ) ) ); ?>" class="bg-blue-600 text-white px-6 py-2 rounded-full font-medium hover:bg-blue-700 transition-all transform hover:scale-105 shadow-lg hover:shadow-blue-200"><?php td_e( 'header_cta_text' ); ?></a>
					<?php endif; ?>
				</div>

				<div class="md:hidden flex items-center">
					<button type="button" id="td-menu-btn" class="text-slate-700 hover:text-blue-600 transition-colors" aria-expanded="false" aria-controls="td-mobile-menu" aria-label="<?php esc_attr_e( 'Toggle menu', 'techdeployers' ); ?>">
						<span class="td-icon-open"><?php td_icon( 'menu', 28 ); ?></span>
						<span class="td-icon-close hidden"><?php td_icon( 'x', 28 ); ?></span>
					</button>
				</div>
			</div>
		</div>

		<div id="td-mobile-menu" class="hidden md:hidden absolute top-full left-0 w-full bg-white shadow-xl border-b border-slate-100">
			<div class="px-4 pt-2 pb-6 space-y-2">
				<?php foreach ( $td_links as $link ) : ?>
					<a href="<?php echo esc_url( $link['url'] ); ?>" class="block px-3 py-3 rounded-md font-medium transition-colors <?php echo td_is_current( $link['url'] ) ? 'text-blue-600 bg-blue-50' : 'text-slate-700 hover:text-blue-600 hover:bg-blue-50'; ?>"><?php echo esc_html( $link['name'] ); ?></a>
				<?php endforeach; ?>
				<?php if ( td_opt( 'header_cta_text' ) ) : ?>
					<a href="<?php echo esc_url( td_link( td_opt( 'header_cta_url' ) ) ); ?>" class="block text-center bg-blue-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-blue-700 transition-all"><?php td_e( 'header_cta_text' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</nav>
	<main id="td-main" class="flex-grow">
