<?php
/**
 * Admin: "TechDeployers" setup screen (demo import + quick links) and activation notice.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_switch_theme', function () {
	flush_rewrite_rules();
	update_option( 'td_show_welcome', 1 );
} );

add_action( 'admin_notices', function () {
	if ( ! get_option( 'td_show_welcome' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen && 'toplevel_page_td-setup' === $screen->id ) {
		return;
	}
	printf(
		'<div class="notice notice-info is-dismissible"><p><strong>%s</strong> %s <a class="button button-primary" href="%s">%s</a></p></div>',
		esc_html__( 'TechDeployers theme activated.', 'techdeployers' ),
		esc_html__( 'Import the original site content in one click:', 'techdeployers' ),
		esc_url( admin_url( 'admin.php?page=td-setup' ) ),
		esc_html__( 'Open setup', 'techdeployers' )
	);
} );

add_action( 'admin_menu', function () {
	add_menu_page( 'TechDeployers', 'TechDeployers', 'manage_options', 'td-setup', 'td_setup_page', 'dashicons-admin-site-alt3', 3 );
} );

function td_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$log = array();
	if ( isset( $_POST['td_import'] ) && check_admin_referer( 'td_import' ) ) {
		$opts = array();
		foreach ( array( 'pages', 'services', 'testimonials', 'capabilities', 'posts', 'menus', 'permalinks' ) as $k ) {
			$opts[ $k ] = ! empty( $_POST[ 'td_' . $k ] );
		}
		$log = td_import_demo( $opts );
		delete_option( 'td_show_welcome' );
	}
	$links = array(
		array( __( 'Edit page texts (live preview)', 'techdeployers' ), admin_url( 'customize.php?autofocus[panel]=td_panel' ), __( 'Hero, stats, about, contact details, footer…', 'techdeployers' ) ),
		array( __( 'Services', 'techdeployers' ), admin_url( 'edit.php?post_type=td_service' ), __( 'Services page + detail pages + pricing plans', 'techdeployers' ) ),
		array( __( 'Testimonials', 'techdeployers' ), admin_url( 'edit.php?post_type=td_testimonial' ), __( 'YouTube video reviews on the home page', 'techdeployers' ) ),
		array( __( 'Capabilities', 'techdeployers' ), admin_url( 'edit.php?post_type=td_capability' ), __( 'Home page capability cards and groups', 'techdeployers' ) ),
		array( __( 'Blog posts', 'techdeployers' ), admin_url( 'edit.php' ), __( 'Normal WordPress posts', 'techdeployers' ) ),
		array( __( 'Leads', 'techdeployers' ), admin_url( 'edit.php?post_type=td_lead' ), __( 'Contact form messages and newsletter sign-ups', 'techdeployers' ) ),
		array( __( 'Menus', 'techdeployers' ), admin_url( 'nav-menus.php' ), __( 'Header and footer links', 'techdeployers' ) ),
	);
	?>
	<div class="wrap">
		<h1>TechDeployers</h1>

		<?php if ( $log ) : ?>
			<div class="notice notice-success"><p><strong><?php esc_html_e( 'Import finished:', 'techdeployers' ); ?></strong></p><ul style="list-style:disc;margin-left:20px">
				<?php foreach ( $log as $line ) : ?><li><?php echo esc_html( $line ); ?></li><?php endforeach; ?>
			</ul><p><a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank"><?php esc_html_e( 'View site', 'techdeployers' ); ?></a></p></div>
		<?php endif; ?>

		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;margin-top:20px">
			<div class="card" style="max-width:none;margin:0">
				<h2><?php esc_html_e( '1. Import demo content', 'techdeployers' ); ?></h2>
				<p><?php esc_html_e( 'Recreates everything from the React site. Items that already exist are skipped, so it is safe to run again.', 'techdeployers' ); ?></p>
				<form method="post">
					<?php wp_nonce_field( 'td_import' ); ?>
					<?php
					$boxes = array(
						'pages'        => __( 'Pages: Home, About Us, Contact Us, Blog (and set them as front / posts page)', 'techdeployers' ),
						'services'     => __( '6 services with details and pricing', 'techdeployers' ),
						'testimonials' => __( '4 video testimonials', 'techdeployers' ),
						'capabilities' => __( '8 capability cards in 2 groups', 'techdeployers' ),
						'posts'        => __( '6 blog posts with categories', 'techdeployers' ),
						'menus'        => __( 'Header + footer menus', 'techdeployers' ),
						'permalinks'   => __( 'Use /blog/post-name/ URLs for posts (same as the React site)', 'techdeployers' ),
					);
					foreach ( $boxes as $k => $label ) {
						printf( '<p><label><input type="checkbox" name="td_%s" value="1" checked> %s</label></p>', esc_attr( $k ), esc_html( $label ) );
					}
					?>
					<p><button type="submit" name="td_import" value="1" class="button button-primary button-hero"><?php esc_html_e( 'Import now', 'techdeployers' ); ?></button></p>
				</form>
			</div>

			<div class="card" style="max-width:none;margin:0">
				<h2><?php esc_html_e( '2. Manage your site', 'techdeployers' ); ?></h2>
				<table class="widefat striped"><tbody>
				<?php foreach ( $links as $l ) : ?>
					<tr><td><a href="<?php echo esc_url( $l[1] ); ?>"><strong><?php echo esc_html( $l[0] ); ?></strong></a></td><td><?php echo esc_html( $l[2] ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
				<p class="description" style="margin-top:12px"><?php esc_html_e( 'Tip: if a new service page shows "Not found", open Settings → Permalinks and click Save once.', 'techdeployers' ); ?></p>
			</div>
		</div>
	</div>
	<?php
}
