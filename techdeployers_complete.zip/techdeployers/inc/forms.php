<?php
/**
 * Contact form + footer newsletter. Submissions are emailed AND saved as "Leads".
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'admin_post_nopriv_td_contact', 'td_handle_contact' );
add_action( 'admin_post_td_contact', 'td_handle_contact' );
add_action( 'admin_post_nopriv_td_newsletter', 'td_handle_newsletter' );
add_action( 'admin_post_td_newsletter', 'td_handle_newsletter' );

function td_form_redirect( $status, $anchor ) {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$back = remove_query_arg( array( 'td_contact', 'td_newsletter' ), $back );
	wp_safe_redirect( add_query_arg( $anchor, $status, $back ) . '#' . $anchor );
	exit;
}

function td_handle_contact() {
	if ( ! isset( $_POST['td_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['td_nonce'] ) ), 'td_contact' ) ) {
		td_form_redirect( 'error', 'td_contact' );
	}
	// Honeypot: real visitors never fill this hidden field.
	if ( ! empty( $_POST['td_website'] ) ) {
		td_form_redirect( 'sent', 'td_contact' );
	}
	$first   = sanitize_text_field( wp_unslash( isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' ) );
	$last    = sanitize_text_field( wp_unslash( isset( $_POST['last_name'] ) ? $_POST['last_name'] : '' ) );
	$email   = sanitize_email( wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : '' ) );
	$message = sanitize_textarea_field( wp_unslash( isset( $_POST['message'] ) ? $_POST['message'] : '' ) );

	if ( ! $first || ! is_email( $email ) || ! $message ) {
		td_form_redirect( 'invalid', 'td_contact' );
	}

	$name = trim( $first . ' ' . $last );
	$id   = wp_insert_post( array(
		'post_type'    => 'td_lead',
		'post_status'  => 'private',
		'post_title'   => $name,
		'post_content' => $message,
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_td_type', 'contact' );
		update_post_meta( $id, '_td_email', $email );
	}

	$to = td_opt( 'contact_recipient' );
	$to = is_email( $to ) ? $to : get_option( 'admin_email' );
	/* translators: %s: visitor name */
	$subject = sprintf( __( 'New enquiry from %s', 'techdeployers' ), $name );
	$body    = "Name: {$name}\nEmail: {$email}\n\n{$message}\n";
	wp_mail( $to, $subject, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );

	td_form_redirect( 'sent', 'td_contact' );
}

function td_handle_newsletter() {
	if ( ! isset( $_POST['td_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['td_nonce'] ) ), 'td_newsletter' ) ) {
		td_form_redirect( 'error', 'td_newsletter' );
	}
	if ( ! empty( $_POST['td_website'] ) ) {
		td_form_redirect( 'sent', 'td_newsletter' );
	}
	$email = sanitize_email( wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : '' ) );
	if ( ! is_email( $email ) ) {
		td_form_redirect( 'invalid', 'td_newsletter' );
	}
	$exists = get_posts( array( 'post_type' => 'td_lead', 'post_status' => 'private', 'meta_key' => '_td_email', 'meta_value' => $email, 'fields' => 'ids', 'numberposts' => 1 ) );
	if ( ! $exists ) {
		$id = wp_insert_post( array( 'post_type' => 'td_lead', 'post_status' => 'private', 'post_title' => $email ) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_td_type', 'newsletter' );
			update_post_meta( $id, '_td_email', $email );
		}
	}
	td_form_redirect( 'sent', 'td_newsletter' );
}

/** Message box for ?td_contact=sent etc. */
function td_form_notice( $form ) {
	$status = isset( $_GET[ $form ] ) ? sanitize_key( $_GET[ $form ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $status ) {
		return;
	}
	$messages = array(
		'sent'    => 'td_contact' === $form ? td_opt( 'contact_success' ) : __( 'Thanks for subscribing!', 'techdeployers' ),
		'invalid' => __( 'Please fill in all required fields with a valid email address.', 'techdeployers' ),
		'error'   => __( 'Something went wrong. Please refresh the page and try again.', 'techdeployers' ),
	);
	if ( ! isset( $messages[ $status ] ) ) {
		return;
	}
	$ok = 'sent' === $status;
	printf(
		'<div role="status" class="mb-6 rounded-2xl px-5 py-4 text-sm font-semibold %s">%s</div>',
		$ok ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200',
		esc_html( $messages[ $status ] )
	);
}
