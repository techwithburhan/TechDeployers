<?php
/**
 * All editable site text lives here: Appearance → Customize → TechDeployers.
 * Defaults are the exact texts from the original React site.
 *
 * Fields with "one per line" use the format shown in their description,
 * with parts separated by a vertical bar ( | ).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function td_customizer_fields() {
	$icons = 'Icon names: ' . implode( ', ', array_keys( td_icon_library() ) );
	return array(
		/* ---------------- Header & footer ---------------- */
		'td_header' => array(
			'title'  => __( 'Header & Footer', 'techdeployers' ),
			'fields' => array(
				'logo_first'        => array( 'Logo text (dark part)', 'text', 'Tech' ),
				'logo_second'       => array( 'Logo text (blue part)', 'text', 'Deployers' ),
				'logo_icon'         => array( 'Logo icon', 'icon', 'code-xml', 'Ignored if you upload a logo image in Site Identity.' ),
				'header_cta_text'   => array( 'Header button text', 'text', 'Get Started' ),
				'header_cta_url'    => array( 'Header button link', 'text', '/contact/', 'Use /page-slug/ for internal pages or a full URL.' ),
				'footer_text'       => array( 'Footer description', 'textarea', 'Engineering digital excellence through modern technology and innovative design.' ),
				'footer_social'     => array( 'Footer social icons', 'textarea', "code-xml|#\nglobe|#\nmail|mailto:info@techdeployers.com\nserver|#", 'One per line: icon|link. ' . $icons ),
				'newsletter_title'  => array( 'Newsletter title', 'text', 'Newsletter' ),
				'newsletter_text'   => array( 'Newsletter text', 'textarea', 'Subscribe to get the latest tech news and updates.' ),
				'copyright'         => array( 'Copyright text', 'text', 'TechDeployers. All rights reserved.', 'The © symbol and current year are added automatically.' ),
			),
		),
		/* ---------------- Home: hero ---------------- */
		'td_home_hero' => array(
			'title'  => __( 'Home – Hero', 'techdeployers' ),
			'fields' => array(
				'hero_badge'      => array( 'Badge', 'text', 'The Future of Digital Engineering' ),
				'hero_title'      => array( 'Title', 'text', 'Engineering' ),
				'hero_highlight'  => array( 'Title (gradient part)', 'text', 'Digital Excellence.' ),
				'hero_text'       => array( 'Text', 'textarea', 'We specialize in high-end web development, cloud automation, and digital growth strategies for modern enterprises.' ),
				'hero_btn1_text'  => array( 'Primary button text', 'text', 'Launch Project' ),
				'hero_btn1_url'   => array( 'Primary button link', 'text', '/contact/' ),
				'hero_btn2_text'  => array( 'Secondary button text', 'text', 'Our Expertise' ),
				'hero_btn2_url'   => array( 'Secondary button link', 'text', '/services/' ),
				'hero_tiles'      => array( 'Hero tile icons (4)', 'text', 'code-xml, cloud, smartphone, zap', 'Four icon names, comma separated. ' . $icons ),
				'home_marquee'    => array( 'Tech marquee words', 'textarea', 'React, Node.js, AWS, Docker, TypeScript, Shopify, Python, Terraform', 'Comma separated.' ),
				'show_marquee'    => array( 'Show tech marquee', 'checkbox', true ),
			),
		),
		/* ---------------- Home: testimonials ---------------- */
		'td_home_testimonials' => array(
			'title'       => __( 'Home – Testimonials', 'techdeployers' ),
			'description' => __( 'The videos themselves are managed in the "Testimonials" menu in the admin.', 'techdeployers' ),
			'fields'      => array(
				'show_testimonials' => array( 'Show this section', 'checkbox', true ),
				'testi_badge'       => array( 'Badge', 'text', 'Client Success Stories' ),
				'testi_title'       => array( 'Title', 'text', 'Trusted by' ),
				'testi_highlight'   => array( 'Title (gradient part)', 'text', 'Industry Leaders' ),
				'testi_text'        => array( 'Text', 'textarea', 'Real results, real voices. Hear directly from the clients who partnered with us to transform their digital presence.' ),
				'testi_stats'       => array( 'Stats', 'textarea', "150+|Happy Clients\n4.9★|Average Rating\n98%|Satisfaction Rate", 'One per line: value|label' ),
			),
		),
		/* ---------------- Home: capabilities ---------------- */
		'td_home_capabilities' => array(
			'title'       => __( 'Home – Capabilities', 'techdeployers' ),
			'description' => __( 'The cards are managed in the "Capabilities" menu in the admin.', 'techdeployers' ),
			'fields'      => array(
				'show_capabilities' => array( 'Show this section', 'checkbox', true ),
				'cap_badge'         => array( 'Badge', 'text', 'Our Capabilities' ),
				'cap_title'         => array( 'Title', 'text', 'Tailored Solutions for' ),
				'cap_highlight'     => array( 'Title (gradient part)', 'text', 'Modern Problems.' ),
				'cap_text'          => array( 'Side text', 'textarea', "We don't just provide services; we build competitive advantages." ),
			),
		),
		/* ---------------- Home: why choose us ---------------- */
		'td_home_why' => array(
			'title'  => __( 'Home – Why Choose Us', 'techdeployers' ),
			'fields' => array(
				'show_why'      => array( 'Show this section', 'checkbox', true ),
				'why_title'     => array( 'Title', 'text', 'Why Industry Leaders' ),
				'why_highlight' => array( 'Title (blue part)', 'text', 'Trust Our Engineering.' ),
				'why_features'  => array( 'Features', 'textarea', "shield|High Availability|Architecting systems with 99.9% uptime guarantees.\nrocket|Scalable Architecture|Built to grow from 10 to 10 million users.\ncpu|Automated Workflows|Reducing human error through DevOps excellence.", 'One per line: icon|title|text. ' . $icons ),
				'why_stats'     => array( 'Stat boxes (4)', 'textarea', "98%|Client Retention\n24/7|Cloud Monitoring\n15+|Industry Awards\n500+|Projects Delivered", 'Exactly 4 lines: value|label' ),
			),
		),
		/* ---------------- Home: blog + CTA ---------------- */
		'td_home_blog' => array(
			'title'  => __( 'Home – Blog & Final CTA', 'techdeployers' ),
			'fields' => array(
				'show_home_blog'  => array( 'Show latest posts', 'checkbox', true ),
				'hblog_badge'     => array( 'Blog badge', 'text', 'From Our Blog' ),
				'hblog_title'     => array( 'Blog title', 'text', 'Latest Insights &' ),
				'hblog_highlight' => array( 'Blog title (gradient part)', 'text', 'Industry Updates' ),
				'hblog_btn'       => array( 'Blog button text', 'text', 'View All Articles' ),
				'show_home_cta'   => array( 'Show final CTA', 'checkbox', true ),
				'cta_title'       => array( 'CTA title', 'text', 'Ready to transform your digital presence?' ),
				'cta_btn_text'    => array( 'CTA button text', 'text', 'Get a Free Consultation' ),
				'cta_btn_url'     => array( 'CTA button link', 'text', '/contact/' ),
			),
		),
		/* ---------------- Services listing page ---------------- */
		'td_services' => array(
			'title'       => __( 'Services Page', 'techdeployers' ),
			'description' => __( 'Text on /services/. The services themselves are managed in the "Services" menu.', 'techdeployers' ),
			'fields'      => array(
				'srv_badge'        => array( 'Hero badge', 'text', 'Empowering Businesses with Modern Tech' ),
				'srv_title'        => array( 'Hero title', 'text', 'Our Premium Digital Services', 'The 2nd word gets the gradient colour.' ),
				'srv_text'         => array( 'Hero text', 'textarea', 'From idea to launch — websites, mobile apps, marketing & infrastructure, crafted by a team that obsesses over performance and design.' ),
				'srv_stats'        => array( 'Hero counters (4)', 'textarea', "150|+|Projects Delivered\n98|%|Client Satisfaction\n50|+|Happy Clients\n24|/7|Premium Support", 'One per line: number|suffix|label' ),
				'srv_marquee'      => array( 'Marquee words', 'textarea', 'React, Next.js, Node.js, WordPress, Android, SEO, UI/UX, TypeScript, Tailwind, Cloud Hosting, API, E-commerce, Digital Marketing, Email Setup, Performance', 'Comma separated.' ),
				'srv_list_badge'   => array( 'List badge', 'text', 'What We Offer' ),
				'srv_list_title'   => array( 'List title', 'text', 'Comprehensive Digital Solutions' ),
				'srv_list_text'    => array( 'List text', 'textarea', 'Explore each service in detail and discover how we help businesses grow with custom digital solutions.' ),
				'srv_btn'          => array( 'Card button text', 'text', 'More Info' ),
				'srv_cta_title'    => array( 'Bottom CTA title', 'text', 'Ready to Transform Your Business?' ),
				'srv_cta_text'     => array( 'Bottom CTA text', 'textarea', 'Learn more about each solution and choose the service that best matches your goals.' ),
				'srv_cta_btn'      => array( 'Bottom CTA button', 'text', 'Browse Services' ),
			),
		),
		/* ---------------- Service detail page ---------------- */
		'td_service_detail' => array(
			'title'  => __( 'Service Detail Pages', 'techdeployers' ),
			'fields' => array(
				'sd_tag'          => array( 'Hero tag', 'text', 'Premium Service Details' ),
				'sd_card1_label'  => array( 'Card row 1 label', 'text', 'Starting Focus' ),
				'sd_card1_text'   => array( 'Card row 1 text', 'text', 'Performance, quality, and business results' ),
				'sd_card2_label'  => array( 'Card row 2 label', 'text', 'Service Coverage' ),
				'sd_card2_text'   => array( 'Card row 2 text', 'text', 'Planning, implementation, launch, and support' ),
				'price_badge'     => array( 'Pricing badge', 'text', 'Pricing Plans' ),
				'price_title'     => array( 'Pricing title', 'text', 'Choose the Right Plan for You' ),
				'price_text'      => array( 'Pricing text', 'textarea', 'Transparent pricing with no hidden costs. Pick a package that fits your business needs, or contact us for a fully custom quote.' ),
				'price_popular'   => array( 'Highlighted plan label', 'text', 'Most Popular' ),
				'price_custom'    => array( 'Custom plan note', 'textarea', 'All packages can be tailored to your specific requirements. Get in touch for a personalized quote.' ),
				'price_custom_btn'=> array( 'Custom plan button', 'text', 'Contact Us for Custom Quote' ),
			),
		),
		/* ---------------- Blog ---------------- */
		'td_blog' => array(
			'title'  => __( 'Blog Pages', 'techdeployers' ),
			'fields' => array(
				'bh_badge'       => array( 'Hero badge', 'text', 'Insights, Guides & Industry Updates' ),
				'bh_before'      => array( 'Title (before)', 'text', 'The' ),
				'bh_highlight'   => array( 'Title (gradient part)', 'text', 'TechDeployers' ),
				'bh_after'       => array( 'Title (after)', 'text', 'Blog' ),
				'bh_text'        => array( 'Hero text', 'textarea', 'Expert insights on web development, mobile apps, digital marketing, cloud hosting, and business technology.' ),
				'bh_featured'    => array( 'Featured heading', 'text', 'Featured Articles', 'Featured articles = posts marked "Stick to the top of the blog".' ),
				'b_cta_title'    => array( 'Blog CTA title', 'text', 'Ready to grow your business online?' ),
				'b_cta_text'     => array( 'Blog CTA text', 'textarea', 'Let us build your website, app, or marketing strategy from scratch.' ),
				'p_author_bio'   => array( 'Article sidebar author text', 'textarea', 'Expert at TechDeployers helping businesses succeed with modern digital solutions.' ),
				'p_cta_title'    => array( 'Article CTA title', 'text', 'Ready to take action?' ),
				'p_cta_text'     => array( 'Article CTA text', 'textarea', 'Let TechDeployers build your next digital solution — website, app, or marketing campaign.' ),
			),
		),
		/* ---------------- About ---------------- */
		'td_about' => array(
			'title'       => __( 'About Page', 'techdeployers' ),
			'description' => __( 'The paragraphs under the heading come from the page editor (Pages → About Us). Setting a Featured Image on that page replaces the image below.', 'techdeployers' ),
			'fields'      => array(
				'about_badge'        => array( 'Small heading', 'text', 'About TechDeployers' ),
				'about_title'        => array( 'Main heading', 'text', 'We Are Your Partners in Digital Excellence' ),
				'about_image'        => array( 'Image (if the page has no Featured Image)', 'image', 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800' ),
				'about_years'        => array( 'Badge number', 'text', '10+' ),
				'about_years_label'  => array( 'Badge label', 'text', 'Years Experience' ),
				'about_checklist'    => array( 'Checklist', 'textarea', "Expert Team\nInnovative Solutions\nClient-Centric Approach\nProven Track Record", 'One item per line.' ),
				'about_values_title' => array( 'Values title', 'text', 'Our Core Values' ),
				'about_values_text'  => array( 'Values text', 'textarea', 'The principles that guide everything we do and how we interact with our clients.' ),
				'about_values'       => array( 'Values', 'textarea', "lightbulb|Innovation|We stay ahead of the curve, constantly exploring new technologies and methodologies.\naward|Quality|We are committed to delivering excellence in every line of code and every design.\nusers|Client Focus|Your success is our success. We work closely with you to understand your vision.\ntarget|Results Driven|We focus on delivering measurable outcomes that drive real business growth.", 'One per line: icon|title|text. ' . $icons ),
			),
		),
		/* ---------------- Contact ---------------- */
		'td_contact' => array(
			'title'  => __( 'Contact Details & Form', 'techdeployers' ),
			'fields' => array(
				'contact_title'     => array( 'Page heading', 'text', "Let's Connect" ),
				'contact_text'      => array( 'Page intro', 'textarea', 'Ready to start your digital journey? Our team is here to help you navigate the landscape of modern technology.' ),
				'contact_box_title' => array( 'Info box title', 'text', 'Contact Information' ),
				'contact_email'     => array( 'Email', 'text', 'info@techdeployers.com' ),
				'contact_phone'     => array( 'Phone', 'text', '+91 (759) 764-5334' ),
				'contact_address'   => array( 'Address', 'textarea', 'We operate remotely and serve clients worldwide' ),
				'contact_recipient' => array( 'Send form messages to', 'text', '', 'Email that receives contact-form messages. Empty = the site admin email. Every message is also saved under "Leads" in the admin.' ),
				'contact_success'   => array( 'Success message', 'text', "Thanks! Your message has been sent. We'll get back to you shortly." ),
			),
		),
	);
}

function td_customizer_defaults() {
	static $defaults = null;
	if ( null === $defaults ) {
		$defaults = array();
		foreach ( td_customizer_fields() as $section ) {
			foreach ( $section['fields'] as $key => $f ) {
				$defaults[ $key ] = $f[2];
			}
		}
	}
	return $defaults;
}

add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {
	$wp_customize->add_panel( 'td_panel', array(
		'title'    => __( 'TechDeployers', 'techdeployers' ),
		'priority' => 20,
	) );

	$priority = 1;
	foreach ( td_customizer_fields() as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array(
			'title'       => $section['title'],
			'panel'       => 'td_panel',
			'priority'    => $priority++,
			'description' => isset( $section['description'] ) ? $section['description'] : '',
		) );

		foreach ( $section['fields'] as $key => $f ) {
			list( $label, $type, $default ) = $f;
			$desc = isset( $f[3] ) ? $f[3] : '';

			$sanitize = 'sanitize_text_field';
			if ( 'textarea' === $type ) {
				$sanitize = 'sanitize_textarea_field';
			} elseif ( 'image' === $type ) {
				$sanitize = 'esc_url_raw';
			} elseif ( 'checkbox' === $type ) {
				$sanitize = function ( $v ) { return (bool) $v; };
			}

			$wp_customize->add_setting( $key, array(
				'default'           => $default,
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			) );

			$control = array(
				'label'       => $label,
				'section'     => $section_id,
				'description' => $desc,
				'type'        => $type,
			);
			if ( 'icon' === $type ) {
				$control['type']        = 'select';
				$control['choices']     = td_icon_choices();
				$control['description'] = $desc;
			}
			if ( 'image' === $type ) {
				$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $key, $control ) );
				continue;
			}
			$wp_customize->add_control( $key, $control );
		}
	}
} );
