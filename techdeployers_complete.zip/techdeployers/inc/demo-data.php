<?php
/**
 * One-click importer that recreates the original React site content.
 * Safe to run more than once: existing items (same slug/title) are skipped.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function td_demo_json( $file ) {
	$path = TD_DIR . '/inc/demo/' . $file . '.json';
	return file_exists( $path ) ? json_decode( file_get_contents( $path ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

function td_find_post( $type, $slug_or_title, $by = 'slug' ) {
	if ( 'slug' === $by ) {
		$p = get_page_by_path( $slug_or_title, OBJECT, $type );
		return $p ? $p->ID : 0;
	}
	$q = get_posts( array( 'post_type' => $type, 'title' => $slug_or_title, 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) );
	return $q ? $q[0] : 0;
}

function td_block_p( $text ) {
	return "<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->\n\n";
}
function td_block_h2( $text ) {
	return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $text ) . "</h2>\n<!-- /wp:heading -->\n\n";
}
function td_block_list( $items ) {
	$li = '';
	foreach ( $items as $item ) {
		$li .= "<!-- wp:list-item -->\n<li>" . esc_html( $item ) . "</li>\n<!-- /wp:list-item -->\n";
	}
	return "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . $li . "</ul>\n<!-- /wp:list -->\n\n";
}

function td_ensure_page( $slug, $title, $content = '', $template = '' ) {
	$id = td_find_post( 'page', $slug );
	if ( ! $id ) {
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $slug,
			'post_title'   => $title,
			'post_content' => $content,
		) );
	}
	if ( $template && $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	return (int) $id;
}

/**
 * @param array $opts pages, services, testimonials, capabilities, posts, menus, permalinks (bool each).
 * @return array log lines
 */
function td_import_demo( $opts ) {
	$log = array();

	/* ---------- Pages ---------- */
	if ( ! empty( $opts['pages'] ) ) {
		$home    = td_ensure_page( 'home', 'Home' );
		$about   = td_ensure_page( 'about', 'About Us',
			td_block_p( 'Founded with a passion for technology and a vision for business growth, TechDeployers has grown into a leading provider of digital solutions. We believe that technology should be an enabler, not a barrier, to your success.' ) .
			td_block_p( 'Our team of dedicated experts works tirelessly to deliver high-quality, innovative, and impactful solutions that help our clients navigate the ever-changing digital landscape.' ),
			'template-about.php' );
		$contact = td_ensure_page( 'contact', 'Contact Us', '', 'template-contact.php' );
		$blog    = td_ensure_page( 'blog', 'Blog' );
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home );
		update_option( 'page_for_posts', $blog );
		update_option( 'posts_per_page', 9 );
		$sample = get_page_by_path( 'sample-page' );
		if ( $sample && $sample->post_modified === $sample->post_date ) {
			wp_trash_post( $sample->ID );
		}
		$log[] = 'Pages ready: Home (front page), About Us, Contact Us, Blog (posts page).';
	}

	/* ---------- Services ---------- */
	if ( ! empty( $opts['services'] ) ) {
		$n = 0;
		foreach ( td_demo_json( 'services' ) as $i => $s ) {
			if ( td_find_post( 'td_service', $s['slug'] ) ) {
				continue;
			}
			$id = wp_insert_post( array(
				'post_type'    => 'td_service',
				'post_status'  => 'publish',
				'post_name'    => $s['slug'],
				'post_title'   => $s['title'],
				'post_excerpt' => $s['shortDescription'],
				'post_content' => td_block_p( $s['overview'] ),
				'menu_order'   => $i + 1,
			) );
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_td_hero_desc', $s['heroDescription'] );
			update_post_meta( $id, '_td_icon', $s['icon'] );
			update_post_meta( $id, '_td_color', $s['color'] );
			update_post_meta( $id, '_td_features', implode( "\n", $s['features'] ) );
			update_post_meta( $id, '_td_benefits', implode( "\n", $s['benefits'] ) );
			update_post_meta( $id, '_td_deliverables', implode( "\n", $s['deliverables'] ) );
			update_post_meta( $id, '_td_process', implode( "\n", $s['process'] ) );
			update_post_meta( $id, '_td_ideal_for', implode( "\n", $s['idealFor'] ) );
			update_post_meta( $id, '_td_technologies', implode( "\n", $s['technologies'] ) );
			$plans = array();
			foreach ( $s['pricing'] as $p ) {
				$plans[] = array(
					'name'        => $p['name'],
					'price'       => $p['price'],
					'note'        => isset( $p['priceNote'] ) ? $p['priceNote'] : '',
					'desc'        => $p['description'],
					'features'    => implode( "\n", $p['features'] ),
					'cta'         => isset( $p['cta'] ) ? $p['cta'] : '',
					'highlighted' => empty( $p['highlighted'] ) ? '' : '1',
				);
			}
			update_post_meta( $id, '_td_pricing', $plans );
			$n++;
		}
		$log[] = "Services imported: {$n}.";
	}

	/* ---------- Testimonials ---------- */
	if ( ! empty( $opts['testimonials'] ) ) {
		$n = 0;
		foreach ( td_demo_json( 'testimonials' ) as $i => $t ) {
			if ( td_find_post( 'td_testimonial', $t['name'], 'title' ) ) {
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'td_testimonial', 'post_status' => 'publish', 'post_title' => $t['name'], 'menu_order' => $i + 1 ) );
			if ( is_wp_error( $id ) ) {
				continue;
			}
			foreach ( array( '_td_role' => 'role', '_td_company' => 'company', '_td_video' => 'video', '_td_avatar' => 'avatar', '_td_quote' => 'quote', '_td_rating' => 'rating', '_td_tag' => 'tag', '_td_tag_color' => 'tagColor' ) as $meta => $field ) {
				update_post_meta( $id, $meta, $t[ $field ] );
			}
			$n++;
		}
		$log[] = "Testimonials imported: {$n}.";
	}

	/* ---------- Capabilities ---------- */
	if ( ! empty( $opts['capabilities'] ) ) {
		$n      = 0;
		$groups = array();
		foreach ( td_demo_json( 'capabilities' ) as $i => $c ) {
			if ( ! isset( $groups[ $c['group'] ] ) ) {
				$term = term_exists( $c['group'], 'td_cap_group' );
				if ( ! $term ) {
					$term = wp_insert_term( $c['group'], 'td_cap_group' );
				}
				$groups[ $c['group'] ] = (int) $term['term_id'];
				update_term_meta( $groups[ $c['group'] ], 'td_order', count( $groups ) );
			}
			if ( td_find_post( 'td_capability', $c['title'], 'title' ) ) {
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'td_capability', 'post_status' => 'publish', 'post_title' => $c['title'], 'menu_order' => $i + 1 ) );
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_td_desc', $c['desc'] );
			update_post_meta( $id, '_td_icon', $c['icon'] );
			update_post_meta( $id, '_td_color', $c['color'] );
			update_post_meta( $id, '_td_link', $c['link'] );
			wp_set_object_terms( $id, array( $groups[ $c['group'] ] ), 'td_cap_group' );
			$n++;
		}
		$log[] = "Capability cards imported: {$n}.";
	}

	/* ---------- Blog posts ---------- */
	if ( ! empty( $opts['posts'] ) ) {
		$n      = 0;
		$sticky = (array) get_option( 'sticky_posts', array() );
		foreach ( td_demo_json( 'posts' ) as $p ) {
			if ( td_find_post( 'post', $p['slug'] ) ) {
				continue;
			}
			$cat = term_exists( $p['category'], 'category' );
			if ( ! $cat ) {
				$cat = wp_insert_term( $p['category'], 'category' );
				update_term_meta( (int) $cat['term_id'], 'td_color', $p['categoryColor'] );
			}
			$content = '';
			foreach ( $p['sections'] as $sec ) {
				$content .= td_block_h2( $sec['heading'] ) . td_block_p( $sec['body'] );
				if ( ! empty( $sec['bullets'] ) ) {
					$content .= td_block_list( $sec['bullets'] );
				}
			}
			$time = strtotime( $p['date'] );
			$id   = wp_insert_post( array(
				'post_type'     => 'post',
				'post_status'   => 'publish',
				'post_name'     => $p['slug'],
				'post_title'    => $p['title'],
				'post_excerpt'  => $p['excerpt'],
				'post_content'  => $content,
				'post_date'     => $time ? gmdate( 'Y-m-d 10:00:00', $time ) : current_time( 'mysql' ),
				'post_category' => array( (int) $cat['term_id'] ),
				'tags_input'    => $p['tags'],
			) );
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_td_author_name', $p['author'] );
			update_post_meta( $id, '_td_author_role', $p['authorRole'] );
			update_post_meta( $id, '_td_read_time', $p['readTime'] );
			update_post_meta( $id, '_td_cover_url', $p['coverImage'] );
			if ( ! empty( $p['featured'] ) ) {
				$sticky[] = $id;
			}
			$n++;
		}
		// Remove WordPress's untouched sample post ("Hello world!") so it doesn't appear on the site.
		$hello = get_page_by_path( 'hello-world', OBJECT, 'post' );
		if ( $hello && $hello->post_modified === $hello->post_date ) {
			wp_trash_post( $hello->ID );
		}
		update_option( 'sticky_posts', array_values( array_unique( array_map( 'intval', $sticky ) ) ) );
		$log[] = "Blog posts imported: {$n}.";
	}

	/* ---------- Menus ---------- */
	if ( ! empty( $opts['menus'] ) ) {
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		$make      = function ( $name, $items ) {
			$menu = wp_get_nav_menu_object( $name );
			if ( $menu ) {
				return $menu->term_id;
			}
			$menu_id = wp_create_nav_menu( $name );
			foreach ( $items as $title => $target ) {
				if ( is_int( $target ) ) {
					wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => $title, 'menu-item-object' => 'page', 'menu-item-object-id' => $target, 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
				} else {
					wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => $title, 'menu-item-url' => $target, 'menu-item-type' => 'custom', 'menu-item-status' => 'publish' ) );
				}
			}
			return $menu_id;
		};
		$page = function ( $slug ) {
			$id = td_find_post( 'page', $slug );
			return $id ? (int) $id : home_url( '/' . $slug . '/' );
		};
		$locations['primary']         = $make( 'Main Menu', array(
			'Home'       => home_url( '/' ),
			'Services'   => home_url( '/services/' ),
			'About Us'   => $page( 'about' ),
			'Blog'       => $page( 'blog' ),
			'Contact Us' => $page( 'contact' ),
		) );
		$locations['footer_services'] = $make( 'Footer Services', array(
			'Web Development'   => home_url( '/services/custom-website-development/' ),
			'App Development'   => home_url( '/services/android-application/' ),
			'Digital Marketing' => home_url( '/services/digital-marketing/' ),
			'Cloud Solutions'   => home_url( '/services/domain-hosting-setup/' ),
		) );
		$privacy                      = (int) get_option( 'wp_page_for_privacy_policy' );
		$locations['footer_company']  = $make( 'Footer Company', array(
			'About Us'         => $page( 'about' ),
			'Contact Us'       => $page( 'contact' ),
			'Privacy Policy'   => $privacy ? $privacy : '#',
			'Terms of Service' => '#',
		) );
		set_theme_mod( 'nav_menu_locations', $locations );
		$log[] = 'Menus created and assigned (Main Menu, Footer Services, Footer Company).';
	}

	/* ---------- Permalinks ---------- */
	if ( ! empty( $opts['permalinks'] ) ) {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/blog/%postname%/' );
		$log[] = 'Permalinks set to /blog/post-name/ (services stay at /services/name/).';
	}
	flush_rewrite_rules();

	return $log;
}
