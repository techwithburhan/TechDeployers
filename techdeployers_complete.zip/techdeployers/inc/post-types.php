<?php
/**
 * Content types managed from the admin:
 *  - Services      (td_service)    → /services/ and /services/{slug}/
 *  - Testimonials  (td_testimonial)
 *  - Capabilities  (td_capability) + "Capability groups" (td_cap_group)
 *  - Leads         (td_lead)       → contact form + newsletter submissions (private)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {

	register_post_type( 'td_service', array(
		'labels'        => array(
			'name'          => __( 'Services', 'techdeployers' ),
			'singular_name' => __( 'Service', 'techdeployers' ),
			'add_new_item'  => __( 'Add New Service', 'techdeployers' ),
			'edit_item'     => __( 'Edit Service', 'techdeployers' ),
			'all_items'     => __( 'All Services', 'techdeployers' ),
		),
		'public'        => true,
		'has_archive'   => 'services',
		'rewrite'       => array( 'slug' => 'services', 'with_front' => false ),
		'menu_icon'     => 'dashicons-hammer',
		'menu_position' => 5,
		'show_in_rest'  => true,
		'supports'      => array( 'title', 'editor', 'excerpt', 'page-attributes', 'revisions' ),
	) );

	register_post_type( 'td_testimonial', array(
		'labels'             => array(
			'name'          => __( 'Testimonials', 'techdeployers' ),
			'singular_name' => __( 'Testimonial', 'techdeployers' ),
			'add_new_item'  => __( 'Add New Testimonial', 'techdeployers' ),
			'edit_item'     => __( 'Edit Testimonial', 'techdeployers' ),
		),
		'public'             => false,
		'show_ui'            => true,
		'menu_icon'          => 'dashicons-format-video',
		'menu_position'      => 6,
		'supports'           => array( 'title', 'thumbnail', 'page-attributes' ),
	) );

	register_post_type( 'td_capability', array(
		'labels'        => array(
			'name'          => __( 'Capabilities', 'techdeployers' ),
			'singular_name' => __( 'Capability', 'techdeployers' ),
			'add_new_item'  => __( 'Add New Capability', 'techdeployers' ),
			'edit_item'     => __( 'Edit Capability', 'techdeployers' ),
		),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-screenoptions',
		'menu_position' => 7,
		'supports'      => array( 'title', 'page-attributes' ),
	) );

	register_taxonomy( 'td_cap_group', 'td_capability', array(
		'labels'            => array(
			'name'          => __( 'Capability groups', 'techdeployers' ),
			'singular_name' => __( 'Capability group', 'techdeployers' ),
		),
		'public'            => false,
		'show_ui'           => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
	) );

	register_post_type( 'td_lead', array(
		'labels'          => array(
			'name'          => __( 'Leads', 'techdeployers' ),
			'singular_name' => __( 'Lead', 'techdeployers' ),
			'edit_item'     => __( 'View Lead', 'techdeployers' ),
		),
		'public'          => false,
		'show_ui'         => true,
		'menu_icon'       => 'dashicons-email-alt',
		'menu_position'   => 8,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );
} );

/* Services, testimonials and capabilities are ordered by the "Order" field. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_post_type_archive( 'td_service' ) ) {
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'ASC' ) );
		$q->set( 'posts_per_page', -1 );
	}
} );

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && in_array( $q->get( 'post_type' ), array( 'td_service', 'td_testimonial', 'td_capability' ), true ) && ! $q->get( 'orderby' ) ) {
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'ASC' ) );
	}
} );

/** Helpers to query ordered items. */
function td_get_items( $type, $args = array() ) {
	return get_posts( array_merge( array(
		'post_type'      => $type,
		'posts_per_page' => -1,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
		'post_status'    => 'publish',
	), $args ) );
}

/* Leads list: show type + email columns. */
add_filter( 'manage_td_lead_posts_columns', function ( $cols ) {
	return array(
		'cb'       => $cols['cb'],
		'title'    => __( 'Name / subject', 'techdeployers' ),
		'td_type'  => __( 'Type', 'techdeployers' ),
		'td_email' => __( 'Email', 'techdeployers' ),
		'date'     => $cols['date'],
	);
} );
add_action( 'manage_td_lead_posts_custom_column', function ( $col, $id ) {
	if ( 'td_type' === $col ) {
		echo esc_html( ucfirst( get_post_meta( $id, '_td_type', true ) ) );
	}
	if ( 'td_email' === $col ) {
		$email = get_post_meta( $id, '_td_email', true );
		printf( '<a href="mailto:%1$s">%1$s</a>', esc_attr( $email ) );
	}
}, 10, 2 );

/* Services list: show icon + order. */
add_filter( 'manage_td_service_posts_columns', function ( $cols ) {
	$cols['td_order'] = __( 'Order', 'techdeployers' );
	return $cols;
} );
add_filter( 'manage_td_capability_posts_columns', function ( $cols ) {
	$cols['td_order'] = __( 'Order', 'techdeployers' );
	return $cols;
} );
add_filter( 'manage_td_testimonial_posts_columns', function ( $cols ) {
	$cols['td_order'] = __( 'Order', 'techdeployers' );
	return $cols;
} );
foreach ( array( 'td_service', 'td_capability', 'td_testimonial' ) as $td_pt ) {
	add_action( "manage_{$td_pt}_posts_custom_column", function ( $col, $id ) {
		if ( 'td_order' === $col ) {
			echo (int) get_post_field( 'menu_order', $id );
		}
	}, 10, 2 );
}
