<?php
/**
 * Simple meta boxes (no ACF needed). Lists use "one item per line".
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function td_meta_fields() {
	return array(
		'td_service' => array(
			'title'  => __( 'Service details', 'techdeployers' ),
			'help'   => __( 'Title = service name. Excerpt = short description on the Services page. Main editor = "Service Overview" text on the detail page.', 'techdeployers' ),
			'fields' => array(
				'_td_hero_desc'    => array( 'Hero description (top of detail page)', 'textarea' ),
				'_td_icon'         => array( 'Icon', 'icon' ),
				'_td_color'        => array( 'Colour', 'color' ),
				'_td_features'     => array( 'Feature highlights (one per line)', 'lines' ),
				'_td_benefits'     => array( 'Key benefits (one per line)', 'lines' ),
				'_td_deliverables' => array( 'What you get (one per line)', 'lines' ),
				'_td_process'      => array( 'Our process steps (one per line, in order)', 'lines' ),
				'_td_ideal_for'    => array( 'Ideal for (one per line)', 'lines' ),
				'_td_technologies' => array( 'Technologies & tools (one per line)', 'lines' ),
			),
		),
		'td_testimonial' => array(
			'title'  => __( 'Testimonial details', 'techdeployers' ),
			'help'   => __( 'Title = client name. Featured Image = client photo (optional; you can also paste a photo URL below).', 'techdeployers' ),
			'fields' => array(
				'_td_role'      => array( 'Role (e.g. CEO, TechFlow)', 'text' ),
				'_td_company'   => array( 'Company', 'text' ),
				'_td_video'     => array( 'YouTube video URL or ID', 'text' ),
				'_td_quote'     => array( 'Quote', 'textarea' ),
				'_td_rating'    => array( 'Star rating', 'rating' ),
				'_td_tag'       => array( 'Service tag (e.g. Web Development)', 'text' ),
				'_td_tag_color' => array( 'Tag colour', 'color' ),
				'_td_avatar'    => array( 'Photo URL (used if no Featured Image)', 'url' ),
			),
		),
		'td_capability' => array(
			'title'  => __( 'Capability card', 'techdeployers' ),
			'help'   => __( 'Choose a group in the "Capability groups" box. Use the Order field to sort cards.', 'techdeployers' ),
			'fields' => array(
				'_td_desc'  => array( 'Short description', 'textarea' ),
				'_td_icon'  => array( 'Icon', 'icon' ),
				'_td_color' => array( 'Colour', 'color' ),
				'_td_link'  => array( 'Link (optional, e.g. /services/wordpress-website/)', 'text' ),
			),
		),
		'post' => array(
			'title'  => __( 'Article details', 'techdeployers' ),
			'help'   => __( 'All optional. Tick "Stick to the top of the blog" (Post settings) to show the article under Featured Articles. Use H2 headings, paragraphs and bullet lists in the editor – they get the numbered/checkmark styling automatically.', 'techdeployers' ),
			'fields' => array(
				'_td_author_name' => array( 'Author name (overrides the WordPress user)', 'text' ),
				'_td_author_role' => array( 'Author role (e.g. Lead Web Architect)', 'text' ),
				'_td_read_time'   => array( 'Read time (empty = calculated automatically)', 'text' ),
				'_td_cover_url'   => array( 'Cover image URL (used if no Featured Image)', 'url' ),
			),
		),
	);
}

add_action( 'add_meta_boxes', function () {
	foreach ( td_meta_fields() as $type => $box ) {
		add_meta_box( 'td_meta_' . $type, $box['title'], 'td_render_meta_box', $type, 'normal', 'high', array( 'type' => $type ) );
	}
	add_meta_box( 'td_pricing', __( 'Pricing plans', 'techdeployers' ), 'td_render_pricing_box', 'td_service', 'normal', 'default' );
} );

function td_render_meta_box( $post, $box ) {
	$def = td_meta_fields()[ $box['args']['type'] ];
	wp_nonce_field( 'td_meta_save', 'td_meta_nonce' );
	echo '<p class="description" style="margin-bottom:12px">' . esc_html( $def['help'] ) . '</p>';
	echo '<div class="td-meta-grid">';
	foreach ( $def['fields'] as $key => $f ) {
		list( $label, $type ) = $f;
		$val  = get_post_meta( $post->ID, $key, true );
		$wide = in_array( $type, array( 'textarea', 'lines' ), true ) ? ' td-wide' : '';
		echo '<p class="td-field' . esc_attr( $wide ) . '"><label for="' . esc_attr( $key ) . '"><strong>' . esc_html( $label ) . '</strong></label><br>';
		switch ( $type ) {
			case 'textarea':
			case 'lines':
				printf( '<textarea id="%1$s" name="%1$s" rows="%3$d" class="widefat">%2$s</textarea>', esc_attr( $key ), esc_textarea( $val ), 'lines' === $type ? 5 : 3 );
				break;
			case 'icon':
				td_select( $key, td_icon_choices(), $val ? $val : 'code-xml' );
				break;
			case 'color':
				td_select( $key, td_color_choices(), $val ? $val : 'blue' );
				break;
			case 'rating':
				td_select( $key, array( 5 => '★★★★★', 4 => '★★★★', 3 => '★★★', 2 => '★★', 1 => '★' ), $val ? $val : 5 );
				break;
			default:
				printf( '<input type="%4$s" id="%1$s" name="%1$s" value="%2$s" class="widefat" %3$s>', esc_attr( $key ), esc_attr( $val ), '', 'url' === $type ? 'url' : 'text' );
		}
		echo '</p>';
	}
	echo '</div>';
}

function td_select( $name, $choices, $current ) {
	echo '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $name ) . '" class="widefat">';
	foreach ( $choices as $k => $label ) {
		printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( (string) $current, (string) $k, false ), esc_html( $label ) );
	}
	echo '</select>';
}

function td_render_pricing_box( $post ) {
	$plans = get_post_meta( $post->ID, '_td_pricing', true );
	$plans = is_array( $plans ) ? $plans : array();
	echo '<p class="description">' . esc_html__( 'Up to 4 plans. Leave a plan name empty to hide it. Leave all empty to hide the pricing section.', 'techdeployers' ) . '</p>';
	echo '<div class="td-plans">';
	for ( $i = 0; $i < 4; $i++ ) {
		$p = wp_parse_args( isset( $plans[ $i ] ) ? $plans[ $i ] : array(), array( 'name' => '', 'price' => '', 'note' => '', 'desc' => '', 'features' => '', 'highlighted' => '', 'cta' => '' ) );
		$n = 'td_pricing[' . $i . ']';
		?>
		<div class="td-plan">
			<h4><?php printf( esc_html__( 'Plan %d', 'techdeployers' ), $i + 1 ); ?></h4>
			<p><label><?php esc_html_e( 'Name', 'techdeployers' ); ?></label><input class="widefat" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $p['name'] ); ?>"></p>
			<p><label><?php esc_html_e( 'Price (e.g. ₹15,000)', 'techdeployers' ); ?></label><input class="widefat" name="<?php echo esc_attr( $n ); ?>[price]" value="<?php echo esc_attr( $p['price'] ); ?>"></p>
			<p><label><?php esc_html_e( 'Price note (e.g. one-time, /month)', 'techdeployers' ); ?></label><input class="widefat" name="<?php echo esc_attr( $n ); ?>[note]" value="<?php echo esc_attr( $p['note'] ); ?>"></p>
			<p><label><?php esc_html_e( 'Description', 'techdeployers' ); ?></label><textarea class="widefat" rows="2" name="<?php echo esc_attr( $n ); ?>[desc]"><?php echo esc_textarea( $p['desc'] ); ?></textarea></p>
			<p><label><?php esc_html_e( 'Features (one per line)', 'techdeployers' ); ?></label><textarea class="widefat" rows="6" name="<?php echo esc_attr( $n ); ?>[features]"><?php echo esc_textarea( $p['features'] ); ?></textarea></p>
			<p><label><?php esc_html_e( 'Button text', 'techdeployers' ); ?></label><input class="widefat" name="<?php echo esc_attr( $n ); ?>[cta]" value="<?php echo esc_attr( $p['cta'] ); ?>" placeholder="Get Started"></p>
			<p><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[highlighted]" value="1" <?php checked( $p['highlighted'], '1' ); ?>> <?php esc_html_e( 'Highlight as "Most Popular"', 'techdeployers' ); ?></label></p>
		</div>
		<?php
	}
	echo '</div>';
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! isset( $_POST['td_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['td_meta_nonce'] ) ), 'td_meta_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$defs = td_meta_fields();
	if ( isset( $defs[ $post->post_type ] ) ) {
		foreach ( $defs[ $post->post_type ]['fields'] as $key => $f ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] );
			if ( in_array( $f[1], array( 'textarea', 'lines' ), true ) ) {
				$val = sanitize_textarea_field( $raw );
			} elseif ( 'url' === $f[1] ) {
				$val = esc_url_raw( $raw );
			} else {
				$val = sanitize_text_field( $raw );
			}
			update_post_meta( $post_id, $key, $val );
		}
	}
	if ( 'td_service' === $post->post_type && isset( $_POST['td_pricing'] ) && is_array( $_POST['td_pricing'] ) ) {
		$plans = array();
		foreach ( wp_unslash( $_POST['td_pricing'] ) as $p ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$plans[] = array(
				'name'        => sanitize_text_field( isset( $p['name'] ) ? $p['name'] : '' ),
				'price'       => sanitize_text_field( isset( $p['price'] ) ? $p['price'] : '' ),
				'note'        => sanitize_text_field( isset( $p['note'] ) ? $p['note'] : '' ),
				'desc'        => sanitize_textarea_field( isset( $p['desc'] ) ? $p['desc'] : '' ),
				'features'    => sanitize_textarea_field( isset( $p['features'] ) ? $p['features'] : '' ),
				'cta'         => sanitize_text_field( isset( $p['cta'] ) ? $p['cta'] : '' ),
				'highlighted' => empty( $p['highlighted'] ) ? '' : '1',
			);
		}
		update_post_meta( $post_id, '_td_pricing', $plans );
	}
}, 10, 2 );

/* Author "job title" on the user profile (used on blog posts). */
function td_user_field( $user ) {
	?>
	<h2><?php esc_html_e( 'TechDeployers', 'techdeployers' ); ?></h2>
	<table class="form-table"><tr>
		<th><label for="td_job_title"><?php esc_html_e( 'Job title (shown on articles)', 'techdeployers' ); ?></label></th>
		<td><input type="text" name="td_job_title" id="td_job_title" class="regular-text" value="<?php echo esc_attr( get_the_author_meta( 'td_job_title', $user->ID ) ); ?>"></td>
	</tr></table>
	<?php
}
add_action( 'show_user_profile', 'td_user_field' );
add_action( 'edit_user_profile', 'td_user_field' );
function td_user_field_save( $user_id ) {
	if ( current_user_can( 'edit_user', $user_id ) && isset( $_POST['td_job_title'] ) && check_admin_referer( 'update-user_' . $user_id ) ) {
		update_user_meta( $user_id, 'td_job_title', sanitize_text_field( wp_unslash( $_POST['td_job_title'] ) ) );
	}
}
add_action( 'personal_options_update', 'td_user_field_save' );
add_action( 'edit_user_profile_update', 'td_user_field_save' );

/* Small admin stylesheet for the boxes above. */
add_action( 'admin_head', function () {
	echo '<style>.td-meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:4px 20px}.td-meta-grid .td-wide{grid-column:1/-1}.td-plans{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}.td-plan{background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:4px 12px}.td-plan label{font-weight:600}</style>';
} );
