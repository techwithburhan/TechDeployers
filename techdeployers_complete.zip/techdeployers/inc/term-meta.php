<?php
/**
 * Term options: blog category colour (category pill) and capability group order.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---- Blog category colour ---- */
add_action( 'category_add_form_fields', function () {
	echo '<div class="form-field"><label for="td_color">' . esc_html__( 'Badge colour', 'techdeployers' ) . '</label>';
	td_select( 'td_color', td_color_choices(), 'blue' );
	echo '</div>';
} );
add_action( 'category_edit_form_fields', function ( $term ) {
	echo '<tr class="form-field"><th><label for="td_color">' . esc_html__( 'Badge colour', 'techdeployers' ) . '</label></th><td>';
	td_select( 'td_color', td_color_choices(), get_term_meta( $term->term_id, 'td_color', true ) );
	echo '</td></tr>';
} );

/* ---- Capability group order ---- */
add_action( 'td_cap_group_add_form_fields', function () {
	echo '<div class="form-field"><label for="td_order">' . esc_html__( 'Display order', 'techdeployers' ) . '</label><input type="number" name="td_order" id="td_order" value="0"></div>';
} );
add_action( 'td_cap_group_edit_form_fields', function ( $term ) {
	echo '<tr class="form-field"><th><label for="td_order">' . esc_html__( 'Display order', 'techdeployers' ) . '</label></th><td><input type="number" name="td_order" id="td_order" value="' . esc_attr( (int) get_term_meta( $term->term_id, 'td_order', true ) ) . '"></td></tr>';
} );

function td_save_term_meta( $term_id ) {
	if ( ! current_user_can( 'manage_categories' ) ) {
		return;
	}
	// Core term forms already verify their own nonce before these hooks fire.
	if ( isset( $_POST['td_color'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$c = sanitize_key( wp_unslash( $_POST['td_color'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( td_color_choices()[ $c ] ) ) {
			update_term_meta( $term_id, 'td_color', $c );
		}
	}
	if ( isset( $_POST['td_order'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		update_term_meta( $term_id, 'td_order', (int) $_POST['td_order'] ); // phpcs:ignore WordPress.Security.NonceVerification
	}
}
foreach ( array( 'created_category', 'edited_category', 'created_td_cap_group', 'edited_td_cap_group' ) as $td_hook ) {
	add_action( $td_hook, 'td_save_term_meta' );
}

/** Capability groups sorted by their "Display order". */
function td_capability_groups() {
	$terms = get_terms( array( 'taxonomy' => 'td_cap_group', 'hide_empty' => true ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		return (int) get_term_meta( $a->term_id, 'td_order', true ) - (int) get_term_meta( $b->term_id, 'td_order', true );
	} );
	return $terms;
}
