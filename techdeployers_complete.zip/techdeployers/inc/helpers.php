<?php
/**
 * Small helper functions shared by every template.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Print an inline Lucide SVG icon. */
function td_icon( $name, $size = 24, $class = '', $extra = '' ) {
	$lib = td_icon_library();
	if ( ! isset( $lib[ $name ] ) ) {
		$name = 'sparkles';
	}
	// Allow overriding the default fill (e.g. filled stars): fill="currentColor".
	$fill = 'none';
	if ( preg_match( '/fill="([^"]*)"/', $extra, $m ) ) {
		$fill  = $m[1];
		$extra = str_replace( $m[0], '', $extra );
	}
	printf(
		'<svg xmlns="http://www.w3.org/2000/svg" width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="%5$s" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="%2$s" aria-hidden="true" %4$s>%3$s</svg>',
		(int) $size,
		esc_attr( $class ),
		$lib[ $name ], // Trusted static markup from inc/icons.php.
		$extra,
		esc_attr( $fill )
	);
}

/** Icons offered in admin dropdowns. */
function td_icon_choices() {
	$names = array_keys( td_icon_library() );
	return array_combine( $names, $names );
}

/** Read a Customizer value with the theme default as fallback. */
function td_opt( $key ) {
	$defaults = td_customizer_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	// A field emptied in the Customizer stays empty, so badges etc. can be hidden.
	return get_theme_mod( $key, $default );
}

/** Echo an escaped Customizer value. */
function td_e( $key ) {
	echo esc_html( td_opt( $key ) );
}

/**
 * Split a "one item per line, fields separated by |" textarea into arrays.
 * td_lines( "98%|Client Retention\n24/7|Monitoring" ) => [ ['98%','Client Retention'], ... ]
 */
function td_lines( $text, $min_parts = 1 ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line ) );
		$out[] = array_pad( $parts, $min_parts, '' );
	}
	return $out;
}

/** Plain list (one per line) => array of strings. */
function td_list( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ) ) );
}

/** Comma separated list => array. */
function td_csv( $text ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) $text ) ) ) );
}

/** Turn "/contact/" into a full site URL; leave full URLs and #anchors alone. */
function td_link( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return home_url( '/' );
	}
	if ( 0 === strpos( $url, '/' ) && 0 !== strpos( $url, '//' ) ) {
		return home_url( $url );
	}
	return $url;
}

/** URL of the page using a given template, or a fallback path. */
function td_page_url( $template, $fallback ) {
	static $cache = array();
	if ( ! isset( $cache[ $template ] ) ) {
		$pages              = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => $template, 'number' => 1 ) );
		$cache[ $template ] = $pages ? get_permalink( $pages[0] ) : home_url( $fallback );
	}
	return $cache[ $template ];
}
function td_contact_url() { return td_page_url( 'template-contact.php', '/contact/' ); }
function td_about_url()   { return td_page_url( 'template-about.php', '/about/' ); }
function td_services_url() {
	$link = get_post_type_archive_link( 'td_service' );
	return $link ? $link : home_url( '/services/' );
}
function td_blog_url() {
	$id = (int) get_option( 'page_for_posts' );
	return $id ? get_permalink( $id ) : home_url( '/blog/' );
}

/* -------------------------------------------------------------------------
 * Colour palette.
 * Class names are written out in full so the Tailwind build can find them.
 * ---------------------------------------------------------------------- */
function td_color_choices() {
	return array(
		'blue' => 'Blue', 'indigo' => 'Indigo', 'purple' => 'Purple', 'green' => 'Green', 'orange' => 'Orange',
		'red' => 'Red', 'cyan' => 'Cyan', 'amber' => 'Amber', 'pink' => 'Pink', 'slate' => 'Slate',
	);
}

/**
 * @param string $color palette key.
 * @param string $role  soft|icon|chip|solid|hover
 */
function td_color( $color, $role ) {
	$map = array(
		'blue'   => array( 'soft' => 'bg-blue-50',   'icon' => 'text-blue-600',   'chip' => 'bg-blue-100 text-blue-700',     'solid' => 'bg-blue-500',   'hover' => 'hover:border-blue-200 hover:shadow-blue-100' ),
		'indigo' => array( 'soft' => 'bg-indigo-50', 'icon' => 'text-indigo-600', 'chip' => 'bg-indigo-100 text-indigo-700', 'solid' => 'bg-indigo-500', 'hover' => 'hover:border-indigo-200 hover:shadow-indigo-100' ),
		'purple' => array( 'soft' => 'bg-purple-50', 'icon' => 'text-purple-600', 'chip' => 'bg-purple-100 text-purple-700', 'solid' => 'bg-purple-500', 'hover' => 'hover:border-purple-200 hover:shadow-purple-100' ),
		'green'  => array( 'soft' => 'bg-green-50',  'icon' => 'text-green-600',  'chip' => 'bg-green-100 text-green-700',   'solid' => 'bg-green-500',  'hover' => 'hover:border-green-200 hover:shadow-green-100' ),
		'orange' => array( 'soft' => 'bg-orange-50', 'icon' => 'text-orange-600', 'chip' => 'bg-orange-100 text-orange-700', 'solid' => 'bg-orange-500', 'hover' => 'hover:border-orange-200 hover:shadow-orange-100' ),
		'red'    => array( 'soft' => 'bg-red-50',    'icon' => 'text-red-600',    'chip' => 'bg-red-100 text-red-700',       'solid' => 'bg-red-500',    'hover' => 'hover:border-red-200 hover:shadow-red-100' ),
		'cyan'   => array( 'soft' => 'bg-cyan-50',   'icon' => 'text-cyan-600',   'chip' => 'bg-cyan-100 text-cyan-700',     'solid' => 'bg-cyan-500',   'hover' => 'hover:border-cyan-200 hover:shadow-cyan-100' ),
		'amber'  => array( 'soft' => 'bg-amber-50',  'icon' => 'text-amber-600',  'chip' => 'bg-amber-100 text-amber-700',   'solid' => 'bg-amber-500',  'hover' => 'hover:border-amber-200 hover:shadow-amber-100' ),
		'pink'   => array( 'soft' => 'bg-pink-50',   'icon' => 'text-pink-600',   'chip' => 'bg-pink-100 text-pink-700',     'solid' => 'bg-pink-500',   'hover' => 'hover:border-pink-200 hover:shadow-pink-100' ),
		'slate'  => array( 'soft' => 'bg-slate-100', 'icon' => 'text-slate-700',  'chip' => 'bg-slate-200 text-slate-700',   'solid' => 'bg-slate-600',  'hover' => 'hover:border-slate-300 hover:shadow-slate-200' ),
	);
	if ( ! isset( $map[ $color ] ) ) {
		$color = 'blue';
	}
	return $map[ $color ][ $role ];
}

/* -------------------------------------------------------------------------
 * Blog post helpers.
 * ---------------------------------------------------------------------- */

/** First category of a post with its colour chip classes. */
function td_post_category( $post_id = null ) {
	$cats = get_the_category( $post_id );
	if ( ! $cats ) {
		return array( 'name' => '', 'slug' => '', 'class' => td_color( 'blue', 'chip' ), 'link' => '' );
	}
	$cat   = $cats[0];
	$color = get_term_meta( $cat->term_id, 'td_color', true );
	return array(
		'name'  => $cat->name,
		'slug'  => $cat->slug,
		'class' => td_color( $color ? $color : 'blue', 'chip' ),
		'link'  => get_category_link( $cat ),
	);
}

/** Author name/role for a post (per-post override, then the WP user). */
function td_post_author( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$name    = get_post_meta( $post_id, '_td_author_name', true );
	$role    = get_post_meta( $post_id, '_td_author_role', true );
	$author  = (int) get_post_field( 'post_author', $post_id );
	if ( ! $name ) {
		$name = get_the_author_meta( 'display_name', $author );
	}
	if ( ! $role ) {
		$role = get_the_author_meta( 'td_job_title', $author );
	}
	$words    = preg_split( '/\s+/', trim( $name ) );
	$initials = '';
	foreach ( array_slice( $words, 0, 2 ) as $w ) {
		$initials .= function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $w, 0, 1 ) ) : strtoupper( substr( $w, 0, 1 ) );
	}
	return array( 'name' => $name, 'role' => $role, 'initials' => $initials );
}

/** "6 min read" — manual value or calculated from word count. */
function td_read_time( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$manual  = get_post_meta( $post_id, '_td_read_time', true );
	if ( $manual ) {
		return $manual;
	}
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
	/* translators: %d: minutes */
	return sprintf( __( '%d min read', 'techdeployers' ), max( 1, (int) ceil( $words / 200 ) ) );
}

/** Cover image URL: featured image, else the external URL meta, else a placeholder. */
function td_cover_url( $post_id = null, $size = 'large' ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( has_post_thumbnail( $post_id ) ) {
		return get_the_post_thumbnail_url( $post_id, $size );
	}
	$url = get_post_meta( $post_id, '_td_cover_url', true );
	return $url ? $url : TD_URI . '/assets/placeholder.svg';
}

/* -------------------------------------------------------------------------
 * Navigation (renders a WP menu with the original design, or default links).
 * ---------------------------------------------------------------------- */
function td_menu_links( $location, $fallback ) {
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ $location ] ) ) {
		$items = wp_get_nav_menu_items( $locations[ $location ] );
		if ( $items ) {
			$links = array();
			foreach ( $items as $item ) {
				if ( (int) $item->menu_item_parent ) {
					continue; // Single level menus, like the original design.
				}
				$links[] = array( 'name' => $item->title, 'url' => $item->url, 'target' => $item->target );
			}
			return $links;
		}
	}
	return $fallback;
}

function td_primary_links() {
	return td_menu_links( 'primary', array(
		array( 'name' => __( 'Home', 'techdeployers' ), 'url' => home_url( '/' ) ),
		array( 'name' => __( 'Services', 'techdeployers' ), 'url' => td_services_url() ),
		array( 'name' => __( 'About Us', 'techdeployers' ), 'url' => td_about_url() ),
		array( 'name' => __( 'Blog', 'techdeployers' ), 'url' => td_blog_url() ),
		array( 'name' => __( 'Contact Us', 'techdeployers' ), 'url' => td_contact_url() ),
	) );
}

/** Is this menu URL the page being viewed? */
function td_is_current( $url ) {
	$current = trailingslashit( strtok( home_url( add_query_arg( array() ) ), '?' ) );
	$target  = trailingslashit( strtok( $url, '?' ) );
	if ( $current === $target ) {
		return true;
	}
	// Keep "Services" / "Blog" highlighted on their detail pages.
	if ( is_singular( 'td_service' ) && $target === trailingslashit( td_services_url() ) ) {
		return true;
	}
	if ( ( is_singular( 'post' ) || is_category() || is_tag() || is_search() ) && $target === trailingslashit( td_blog_url() ) ) {
		return true;
	}
	return false;
}

/** Logo (custom logo if uploaded, else the two-tone text logo). */
function td_logo( $dark = false ) {
	if ( has_custom_logo() ) {
		$id  = get_theme_mod( 'custom_logo' );
		$img = wp_get_attachment_image( $id, 'full', false, array( 'class' => 'h-10 w-auto', 'alt' => get_bloginfo( 'name' ) ) );
		printf( '<a href="%s" class="flex items-center">%s</a>', esc_url( home_url( '/' ) ), $img );
		return;
	}
	?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex items-center space-x-2">
		<span class="bg-blue-600 p-2 rounded-lg"><?php td_icon( td_opt( 'logo_icon' ), 24, 'text-white' ); ?></span>
		<span class="text-2xl font-bold tracking-tight <?php echo $dark ? 'text-white' : 'text-slate-900'; ?>">
			<?php td_e( 'logo_first' ); ?><span class="text-blue-600"><?php td_e( 'logo_second' ); ?></span>
		</span>
	</a>
	<?php
}

/** YouTube ID from a full URL or a raw ID. */
function td_youtube_id( $value ) {
	$value = trim( (string) $value );
	if ( preg_match( '~(?:youtu\.be/|v=|embed/|shorts/)([A-Za-z0-9_-]{11})~', $value, $m ) ) {
		return $m[1];
	}
	return preg_match( '~^[A-Za-z0-9_-]{11}$~', $value ) ? $value : '';
}

/** Gradient-highlighted heading helper: "Plain text <span gradient>highlight</span>". */
function td_gradient( $text, $class = 'from-blue-600 to-indigo-500' ) {
	return '<span class="text-transparent bg-clip-text bg-gradient-to-r ' . esc_attr( $class ) . '">' . esc_html( $text ) . '</span>';
}

/** Initials from any name. */
function td_post_author_initials( $name ) {
	$out = '';
	foreach ( array_slice( preg_split( '/\s+/', trim( $name ) ), 0, 2 ) as $w ) {
		$out .= strtoupper( substr( $w, 0, 1 ) );
	}
	return $out;
}
