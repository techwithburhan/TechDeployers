<?php
/**
 * Template Name: Contact (TechDeployers)
 *
 * Contact.tsx with a working form (emails you + saves to Admin → Leads).
 * Anything typed in this page's editor appears under the form (e.g. a map embed).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$service = isset( $_GET['service'] ) ? sanitize_text_field( wp_unslash( $_GET['service'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$prefill = $service ? sprintf( __( "Hi, I'm interested in: %s\n\n", 'techdeployers' ), $service ) : '';
$input   = 'w-full px-6 py-4 bg-slate-50 border border-transparent rounded-2xl focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all outline-none';
$details = array(
	array( 'mail', __( 'Email Us', 'techdeployers' ), td_opt( 'contact_email' ), 'mailto:' . td_opt( 'contact_email' ) ),
	array( 'phone', __( 'Call Us', 'techdeployers' ), td_opt( 'contact_phone' ), 'tel:' . preg_replace( '/[^0-9+]/', '', td_opt( 'contact_phone' ) ) ),
	array( 'map-pin', __( 'Visit Us', 'techdeployers' ), td_opt( 'contact_address' ), '' ),
);
?>
<div class="pt-24 pb-20">
	<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
		<div class="td-fade-up text-center mb-16">
			<h1 class="text-4xl md:text-6xl font-black text-slate-900 mb-6"><?php td_e( 'contact_title' ); ?></h1>
			<p class="text-lg text-slate-600 max-w-3xl mx-auto"><?php td_e( 'contact_text' ); ?></p>
		</div>

		<div class="grid lg:grid-cols-2 gap-12">
			<div class="td-reveal bg-slate-900 rounded-[2.5rem] p-8 md:p-12 text-white">
				<h2 class="text-3xl font-bold mb-8"><?php td_e( 'contact_box_title' ); ?></h2>
				<div class="space-y-8">
					<?php foreach ( $details as $d ) : if ( ! $d[2] ) { continue; } ?>
						<div class="flex items-start space-x-4">
							<div class="bg-blue-600 p-3 rounded-xl shrink-0"><?php td_icon( $d[0], 24 ); ?></div>
							<div class="min-w-0">
								<h3 class="font-bold text-xl"><?php echo esc_html( $d[1] ); ?></h3>
								<?php if ( $d[3] ) : ?>
									<a href="<?php echo esc_url( $d[3] ); ?>" class="text-slate-400 hover:text-white transition-colors break-words"><?php echo esc_html( $d[2] ); ?></a>
								<?php else : ?>
									<p class="text-slate-400"><?php echo nl2br( esc_html( $d[2] ) ); ?></p>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<div id="td_contact" class="td-reveal bg-white border border-slate-100 rounded-[2.5rem] p-8 md:p-12 shadow-sm scroll-mt-28">
				<?php td_form_notice( 'td_contact' ); ?>
				<form class="space-y-6" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="td_contact">
					<?php wp_nonce_field( 'td_contact', 'td_nonce' ); ?>
					<input type="text" name="td_website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">
					<div class="grid md:grid-cols-2 gap-6">
						<div class="space-y-2">
							<label for="td-first" class="text-sm font-bold text-slate-900 uppercase"><?php esc_html_e( 'First Name', 'techdeployers' ); ?></label>
							<input id="td-first" name="first_name" type="text" required class="<?php echo esc_attr( $input ); ?>" placeholder="<?php esc_attr_e( 'Burhan', 'techdeployers' ); ?>">
						</div>
						<div class="space-y-2">
							<label for="td-last" class="text-sm font-bold text-slate-900 uppercase"><?php esc_html_e( 'Last Name', 'techdeployers' ); ?></label>
							<input id="td-last" name="last_name" type="text" class="<?php echo esc_attr( $input ); ?>">
						</div>
					</div>
					<div class="space-y-2">
						<label for="td-email" class="text-sm font-bold text-slate-900 uppercase"><?php esc_html_e( 'Email Address', 'techdeployers' ); ?></label>
						<input id="td-email" name="email" type="email" required class="<?php echo esc_attr( $input ); ?>" placeholder="<?php esc_attr_e( 'you@company.com', 'techdeployers' ); ?>">
					</div>
					<div class="space-y-2">
						<label for="td-msg" class="text-sm font-bold text-slate-900 uppercase"><?php esc_html_e( 'Message', 'techdeployers' ); ?></label>
						<textarea id="td-msg" name="message" rows="4" required class="<?php echo esc_attr( $input ); ?> resize-none" placeholder="<?php esc_attr_e( 'Tell us about your project...', 'techdeployers' ); ?>"><?php echo esc_textarea( $prefill ); ?></textarea>
					</div>
					<button type="submit" class="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-lg hover:bg-blue-500 transition-all shadow-xl shadow-blue-600/20 flex items-center justify-center space-x-2">
						<span><?php esc_html_e( 'Send Message', 'techdeployers' ); ?></span><?php td_icon( 'send', 20 ); ?>
					</button>
				</form>
			</div>
		</div>

		<?php
		while ( have_posts() ) :
			the_post();
			if ( trim( get_the_content() ) ) :
				?>
				<div class="td-prose mt-16 max-w-4xl mx-auto"><?php the_content(); ?></div>
				<?php
			endif;
		endwhile;
		?>
	</div>
</div>
<?php
get_footer();
