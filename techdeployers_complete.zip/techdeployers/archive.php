<?php
/**
 * Blog listing — see template-parts/blog-listing.php.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
get_template_part( 'template-parts/blog-listing' );
get_footer();
