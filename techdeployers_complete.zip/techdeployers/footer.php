<?php
/**
 * Site footer (Footer.tsx) with working newsletter form.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$td_services_links = td_menu_links( 'footer_services', array_map( function ( $p ) {
	return array( 'name' => get_the_title( $p ), 'url' => get_permalink( $p ) );
}, td_get_items( 'td_service', array( 'posts_per_page' => 4 ) ) ) );

$td_company_links = td_menu_links( 'footer_company', array(
	array( 'name' => __( 'About Us', 'techdeployers' ), 'url' => td_about_url() ),
	array( 'name' => __( 'Contact Us', 'techdeployers' ), 'url' => td_contact_url() ),
	array( 'name' => __( 'Privacy Policy', 'techdeployers' ), 'url' => get_privacy_policy_url() ? get_privacy_policy_url() : '#' ),
) );
?>
	</main>
	<footer class="bg-slate-950 text-white pt-20 pb-10">
		<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
			<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
				<div class="space-y-6">
					<?php td_logo( true ); ?>
					<p class="text-slate-400 text-lg leading-relaxed"><?php td_e( 'footer_text' ); ?></p>
					<div class="flex space-x-4">
						<?php foreach ( td_lines( td_opt( 'footer_social' ), 2 ) as $s ) : ?>
							<a href="<?php echo esc_url( $s[1] ? $s[1] : '#' ); ?>" class="p-2 bg-white/5 rounded-lg hover:bg-blue-600 transition-all" aria-label="<?php echo esc_attr( $s[0] ); ?>" <?php echo 0 === strpos( $s[1], 'http' ) ? 'target="_blank" rel="noopener"' : ''; ?>><?php td_icon( $s[0], 20 ); ?></a>
						<?php endforeach; ?>
					</div>
				</div>

				<div>
					<h3 class="text-xl font-bold mb-6"><?php esc_html_e( 'Services', 'techdeployers' ); ?></h3>
					<ul class="space-y-4 text-slate-400">
						<?php foreach ( $td_services_links as $l ) : ?>
							<li><a href="<?php echo esc_url( $l['url'] ); ?>" class="hover:text-blue-400 transition-colors"><?php echo esc_html( $l['name'] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>

				<div>
					<h3 class="text-xl font-bold mb-6"><?php esc_html_e( 'Company', 'techdeployers' ); ?></h3>
					<ul class="space-y-4 text-slate-400">
						<?php foreach ( $td_company_links as $l ) : ?>
							<li><a href="<?php echo esc_url( $l['url'] ); ?>" class="hover:text-blue-400 transition-colors"><?php echo esc_html( $l['name'] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>

				<div id="td_newsletter">
					<h3 class="text-xl font-bold mb-6"><?php td_e( 'newsletter_title' ); ?></h3>
					<p class="text-slate-400 mb-6"><?php td_e( 'newsletter_text' ); ?></p>
					<?php td_form_notice( 'td_newsletter' ); ?>
					<form class="space-y-3" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="td_newsletter">
						<?php wp_nonce_field( 'td_newsletter', 'td_nonce' ); ?>
						<input type="text" name="td_website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">
						<label class="sr-only" for="td-nl-email"><?php esc_html_e( 'Email Address', 'techdeployers' ); ?></label>
						<input id="td-nl-email" type="email" name="email" required placeholder="<?php esc_attr_e( 'Email Address', 'techdeployers' ); ?>" class="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-600 transition-all">
						<button type="submit" class="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-500 transition-all"><?php esc_html_e( 'Subscribe', 'techdeployers' ); ?></button>
					</form>
				</div>
			</div>

			<div class="border-t border-white/10 pt-10 text-center text-slate-500 text-sm">
				<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php td_e( 'copyright' ); ?></p>
			</div>
		</div>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
