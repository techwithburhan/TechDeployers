<?php
/**
 * /services/ (Services.tsx).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$words = td_csv( td_opt( 'srv_marquee' ) );
$title = preg_split( '/\s+/', trim( td_opt( 'srv_title' ) ) );
$stats = td_lines( td_opt( 'srv_stats' ), 3 );
?>
<div class="bg-slate-50 min-h-screen overflow-hidden">
	<header class="relative isolate overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950 pt-20 md:pt-28 pb-20 md:pb-32">
		<div class="absolute inset-0 -z-10" aria-hidden="true">
			<div class="td-blob-1 absolute top-10 left-10 w-40 md:w-80 h-40 md:h-80 rounded-full bg-blue-500/30 blur-3xl"></div>
			<div class="td-blob-2 absolute top-40 right-10 w-48 md:w-96 h-48 md:h-96 rounded-full bg-purple-500/30 blur-3xl"></div>
			<div class="td-blob-3 absolute bottom-0 left-1/3 w-40 md:w-80 h-40 md:h-80 rounded-full bg-pink-500/20 blur-3xl"></div>
		</div>
		<svg class="absolute inset-0 -z-10 h-full w-full stroke-white/10 [mask-image:radial-gradient(ellipse_at_center,white,transparent_75%)] hidden md:block" aria-hidden="true">
			<defs><pattern id="td-srv-grid" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M.5 60V.5H60" fill="none"/></pattern></defs>
			<rect width="100%" height="100%" fill="url(#td-srv-grid)"/>
		</svg>
		<div class="pointer-events-none absolute inset-0 -z-10 hidden md:block" aria-hidden="true">
			<div class="td-float absolute top-24 left-[8%] p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20"><?php td_icon( 'code-xml', 28, 'text-blue-300' ); ?></div>
			<div class="td-float td-d2 absolute top-40 right-[10%] p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20"><?php td_icon( 'smartphone', 28, 'text-green-300' ); ?></div>
			<div class="td-float td-d3 absolute bottom-32 left-[14%] p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20"><?php td_icon( 'database', 28, 'text-purple-300' ); ?></div>
			<div class="td-float td-d1 absolute bottom-40 right-[16%] p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20"><?php td_icon( 'panels-top-left', 28, 'text-pink-300' ); ?></div>
			<div class="td-float td-d3 absolute top-1/2 left-[5%] p-3 bg-white/10 backdrop-blur-md rounded-xl border border-white/20"><?php td_icon( 'cpu', 22, 'text-yellow-300' ); ?></div>
			<div class="td-float td-d2 absolute top-1/3 right-[5%] p-3 bg-white/10 backdrop-blur-md rounded-xl border border-white/20"><?php td_icon( 'zap', 22, 'text-orange-300' ); ?></div>
		</div>

		<div class="relative max-w-7xl mx-auto px-6 sm:px-6 lg:px-8 flex flex-col items-center justify-center text-center min-h-[50vh] md:min-h-0">
			<?php if ( td_opt( 'srv_badge' ) ) : ?>
				<div class="td-fade-down inline-flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs md:text-sm text-white/90 mb-6 md:mb-8">
					<?php td_icon( 'sparkles', 14, 'text-yellow-300' ); ?><span><?php td_e( 'srv_badge' ); ?></span>
				</div>
			<?php endif; ?>
			<h1 class="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight tracking-tight mb-4 md:mb-6 flex flex-wrap justify-center gap-x-2 md:gap-x-4 gap-y-1 md:gap-y-2">
				<?php foreach ( $title as $i => $word ) : ?>
					<span class="td-word inline-block <?php echo 1 === $i ? 'bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent' : ''; ?>" style="animation-delay:<?php echo esc_attr( 0.3 + $i * 0.12 ); ?>s"><?php echo esc_html( $word ); ?></span>
				<?php endforeach; ?>
			</h1>
			<p class="td-fade-up td-delay-2 max-w-md sm:max-w-2xl mx-auto text-sm sm:text-base md:text-lg lg:text-xl text-slate-300 mb-8 md:mb-12 leading-relaxed"><?php td_e( 'srv_text' ); ?></p>

			<?php if ( $stats ) : ?>
				<div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 max-w-4xl mx-auto mb-10 md:mb-14 px-2">
					<?php foreach ( $stats as $s ) : ?>
						<div class="td-fade-up td-delay-3 p-4 md:p-6 rounded-xl md:rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 hover:border-white/30 hover:-translate-y-1 transition-all duration-300">
							<div class="text-2xl md:text-4xl lg:text-5xl font-extrabold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
								<span data-td-count="<?php echo esc_attr( (int) $s[0] ); ?>" data-suffix="<?php echo esc_attr( $s[1] ); ?>"><?php echo esc_html( $s[0] . $s[1] ); ?></span>
							</div>
							<div class="text-xs md:text-sm text-slate-400 mt-1 md:mt-2"><?php echo esc_html( $s[2] ); ?></div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<a href="#services" class="td-fade-up td-delay-4 inline-flex flex-col items-center gap-1 md:gap-2 text-white/70 hover:text-white transition-colors">
				<span class="text-[10px] md:text-xs uppercase tracking-widest"><?php esc_html_e( 'Explore Services', 'techdeployers' ); ?></span>
				<?php td_icon( 'chevron-down', 20, 'td-bounce' ); ?>
			</a>
		</div>

		<?php if ( $words ) : ?>
			<div class="absolute bottom-0 left-0 right-0 overflow-hidden bg-white/5 backdrop-blur-md border-y border-white/10 py-2 md:py-3" aria-hidden="true">
				<div class="td-marquee td-marquee-slow flex whitespace-nowrap w-max">
					<?php for ( $i = 0; $i < 2; $i++ ) : foreach ( $words as $w ) : ?>
						<div class="flex items-center gap-2 md:gap-3 text-white/70 text-xs md:text-sm font-medium mr-4 md:mr-8"><?php td_icon( 'rocket', 12, 'text-blue-400' ); ?><span><?php echo esc_html( $w ); ?></span></div>
					<?php endforeach; endfor; ?>
				</div>
			</div>
		<?php endif; ?>
	</header>

	<div id="services" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 md:pt-24 pb-12 md:pb-24 scroll-mt-20">
		<div class="td-reveal text-center max-w-3xl mx-auto mb-12 md:mb-20">
			<?php if ( td_opt( 'srv_list_badge' ) ) : ?><h2 class="text-blue-600 font-bold tracking-wider uppercase text-xs md:text-sm mb-2 md:mb-3"><?php td_e( 'srv_list_badge' ); ?></h2><?php endif; ?>
			<h3 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4 md:mb-6"><?php td_e( 'srv_list_title' ); ?></h3>
			<p class="text-base md:text-lg text-slate-600 px-2"><?php td_e( 'srv_list_text' ); ?></p>
		</div>

		<div class="space-y-6 md:space-y-12">
			<?php
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					$color = get_post_meta( get_the_ID(), '_td_color', true );
					?>
					<article class="td-reveal group bg-white rounded-2xl md:rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-slate-100">
						<div class="grid grid-cols-1 lg:grid-cols-2">
							<div class="p-6 md:p-16 <?php echo esc_attr( td_color( $color, 'soft' ) . ' ' . td_color( $color, 'icon' ) ); ?> flex items-center justify-center relative overflow-hidden min-h-[140px]">
								<div class="absolute w-24 md:w-40 h-24 md:h-40 rounded-full border-2 md:border-4 border-current opacity-5"></div>
								<div class="absolute w-32 md:w-56 h-32 md:h-56 rounded-full border-2 md:border-4 border-current opacity-5"></div>
								<div class="absolute w-40 md:w-72 h-40 md:h-72 rounded-full border-2 md:border-4 border-current opacity-5"></div>
								<div class="relative z-10 p-4 md:p-6 rounded-2xl md:rounded-3xl bg-white/80 shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
									<?php td_icon( get_post_meta( get_the_ID(), '_td_icon', true ), 32 ); ?>
								</div>
							</div>
							<div class="p-6 md:p-8 lg:p-16">
								<h3 class="text-xl sm:text-2xl md:text-3xl font-bold text-slate-900 mb-3 md:mb-6 group-hover:text-blue-600 transition-colors duration-300"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p class="text-sm sm:text-base md:text-lg text-slate-600 mb-6 md:mb-8 leading-relaxed"><?php echo esc_html( get_the_excerpt() ); ?></p>
								<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4 mb-6 md:mb-8">
									<?php foreach ( td_list( get_post_meta( get_the_ID(), '_td_features', true ) ) as $feature ) : ?>
										<div class="flex items-center space-x-2 md:space-x-3">
											<div class="flex-shrink-0 w-5 h-5 md:w-6 md:h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300"><?php td_icon( 'circle-check', 12 ); ?></div>
											<span class="text-xs sm:text-sm md:text-base text-slate-700 font-medium"><?php echo esc_html( $feature ); ?></span>
										</div>
									<?php endforeach; ?>
								</div>
								<a href="<?php the_permalink(); ?>" class="w-full sm:w-auto inline-flex items-center justify-center px-5 md:px-6 py-2.5 md:py-3 bg-slate-900 text-white rounded-lg md:rounded-xl font-bold text-sm md:text-base hover:bg-blue-600 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group/btn">
									<?php td_e( 'srv_btn' ); ?> <?php td_icon( 'arrow-right', 18, 'ml-2 group-hover/btn:translate-x-1 transition-transform' ); ?>
								</a>
							</div>
						</div>
					</article>
					<?php
				endwhile;
			else :
				?>
				<p class="text-center text-slate-500"><?php esc_html_e( 'No services yet. Add them in the admin under Services.', 'techdeployers' ); ?></p>
			<?php endif; ?>
		</div>

		<div class="td-reveal mt-12 md:mt-20 text-center p-6 md:p-12 rounded-2xl md:rounded-3xl bg-gradient-to-r from-blue-600 to-purple-600 relative overflow-hidden">
			<div class="td-dots absolute inset-0 opacity-30" aria-hidden="true"></div>
			<div class="relative z-10">
				<h2 class="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-3 md:mb-4"><?php td_e( 'srv_cta_title' ); ?></h2>
				<p class="text-sm md:text-lg text-white/80 mb-6 md:mb-8 max-w-2xl mx-auto px-2"><?php td_e( 'srv_cta_text' ); ?></p>
				<a href="#services" class="w-full sm:w-auto inline-flex items-center justify-center px-6 md:px-8 py-3 md:py-4 bg-white text-blue-600 rounded-lg md:rounded-xl font-bold text-sm md:text-base hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
					<?php td_e( 'srv_cta_btn' ); ?> <?php td_icon( 'arrow-right', 18, 'ml-2' ); ?>
				</a>
			</div>
		</div>
	</div>
</div>
<?php
get_footer();
