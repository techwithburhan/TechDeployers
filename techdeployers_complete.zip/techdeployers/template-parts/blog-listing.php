<?php
/**
 * Blog listing (Blog.tsx) — used by the posts page, category/tag archives and search.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$paged       = max( 1, (int) get_query_var( 'paged' ) );
$is_main     = is_home() && 1 === $paged;
$search_term = get_search_query();
$current_cat = is_category() ? get_queried_object_id() : 0;
$cats        = get_categories( array( 'hide_empty' => true ) );
?>
<div class="min-h-screen bg-slate-50">
	<section class="relative isolate bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 pt-32 pb-20 overflow-hidden">
		<?php get_template_part( 'template-parts/components/dark-bg', null, array( 'id' => 'td-blog-grid' ) ); ?>
		<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
			<?php if ( td_opt( 'bh_badge' ) ) : ?>
				<div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 text-white/80 text-sm mb-6 backdrop-blur-md"><?php td_icon( 'tag', 14, 'text-blue-300' ); ?><span><?php td_e( 'bh_badge' ); ?></span></div>
			<?php endif; ?>
			<h1 class="td-fade-up text-4xl md:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-tight">
				<?php if ( is_category() || is_tag() ) : ?>
					<?php echo esc_html( single_term_title( '', false ) ); ?>
				<?php elseif ( is_search() ) : ?>
					<?php
					/* translators: %s: search term */
					printf( esc_html__( 'Results for “%s”', 'techdeployers' ), esc_html( $search_term ) );
					?>
				<?php else : ?>
					<?php td_e( 'bh_before' ); ?> <span class="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"><?php td_e( 'bh_highlight' ); ?></span> <?php td_e( 'bh_after' ); ?>
				<?php endif; ?>
			</h1>
			<p class="td-fade-up td-delay-2 max-w-2xl mx-auto text-slate-300 text-lg mb-10"><?php echo ( is_category() || is_tag() ) && term_description() ? esc_html( wp_strip_all_tags( term_description() ) ) : esc_html( td_opt( 'bh_text' ) ); ?></p>

			<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="td-fade-up td-delay-3 max-w-xl mx-auto relative">
				<span class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"><?php td_icon( 'search', 20 ); ?></span>
				<input type="hidden" name="post_type" value="post">
				<label class="sr-only" for="td-blog-search"><?php esc_html_e( 'Search articles', 'techdeployers' ); ?></label>
				<input id="td-blog-search" type="search" name="s" value="<?php echo esc_attr( $search_term ); ?>" placeholder="<?php esc_attr_e( 'Search articles...', 'techdeployers' ); ?>" class="td-live-search w-full pl-12 pr-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white placeholder-slate-400 backdrop-blur-md focus:outline-none focus:border-blue-400 focus:bg-white/15 transition-all">
			</form>
		</div>
	</section>

	<?php
	if ( $is_main ) :
		$sticky = get_option( 'sticky_posts' );
		if ( $sticky ) :
			$featured = new WP_Query( array( 'post__in' => $sticky, 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) );
			if ( $featured->have_posts() ) :
				?>
				<section class="td-featured max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
					<h2 class="text-2xl font-bold text-slate-900 mb-8 flex items-center gap-3"><span class="w-8 h-1 bg-blue-600 rounded-full inline-block"></span><?php td_e( 'bh_featured' ); ?></h2>
					<div class="grid md:grid-cols-3 gap-6">
						<?php
						while ( $featured->have_posts() ) :
							$featured->the_post();
							get_template_part( 'template-parts/components/post-card', null, array( 'variant' => 'featured' ) );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		endif;
	endif;
	?>

	<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24 <?php echo $is_main ? '' : 'pt-16'; ?>">
		<?php if ( $cats ) : ?>
			<nav class="flex gap-2 flex-wrap mb-10" aria-label="<?php esc_attr_e( 'Categories', 'techdeployers' ); ?>">
				<?php
				$pill = function ( $label, $url, $active ) {
					printf(
						'<a href="%s" class="px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 %s">%s</a>',
						esc_url( $url ),
						$active ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30' : 'bg-white text-slate-600 border border-slate-200 hover:border-blue-300 hover:text-blue-600',
						esc_html( $label )
					);
				};
				$pill( __( 'All', 'techdeployers' ), td_blog_url(), ! $current_cat && ! is_tag() );
				foreach ( $cats as $c ) {
					$pill( $c->name, get_category_link( $c ), $current_cat === $c->term_id );
				}
				?>
			</nav>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="td-post-grid grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/components/post-card', null, array( 'variant' => 'grid' ) );
				endwhile;
				?>
			</div>
			<div class="td-no-results hidden text-center py-20 text-slate-400">
				<?php td_icon( 'search', 48, 'mx-auto mb-4 opacity-30' ); ?>
				<p class="text-lg font-medium"><?php esc_html_e( 'No articles found. Try a different search.', 'techdeployers' ); ?></p>
			</div>
			<?php
			$links = paginate_links( array( 'type' => 'array', 'prev_text' => '‹', 'next_text' => '›' ) );
			if ( $links ) :
				?>
				<nav class="td-pagination mt-14 flex flex-wrap justify-center gap-2" aria-label="<?php esc_attr_e( 'Pagination', 'techdeployers' ); ?>">
					<?php foreach ( $links as $l ) { echo wp_kses_post( $l ); } ?>
				</nav>
			<?php endif; ?>
		<?php else : ?>
			<div class="text-center py-20 text-slate-400">
				<?php td_icon( 'search', 48, 'mx-auto mb-4 opacity-30' ); ?>
				<p class="text-lg font-medium"><?php esc_html_e( 'No articles found. Try a different search.', 'techdeployers' ); ?></p>
			</div>
		<?php endif; ?>
	</section>

	<?php get_template_part( 'template-parts/components/cta-band', null, array( 'title' => td_opt( 'b_cta_title' ), 'text' => td_opt( 'b_cta_text' ) ) ); ?>
</div>
