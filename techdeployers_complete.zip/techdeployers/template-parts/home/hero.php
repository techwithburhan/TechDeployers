<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$tiles = td_csv( td_opt( 'hero_tiles' ) );
$tiles = array_pad( $tiles, 4, 'sparkles' );
?>
<section class="relative min-h-screen flex items-center pt-20 overflow-hidden">
	<div class="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10" aria-hidden="true">
		<div class="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-100 rounded-full blur-[120px] opacity-50 animate-pulse"></div>
		<div class="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-100 rounded-full blur-[120px] opacity-50"></div>
	</div>

	<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center w-full">
		<div class="td-fade-up space-y-8 text-center lg:text-left">
			<?php if ( td_opt( 'hero_badge' ) ) : ?>
				<div class="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-md border border-slate-200 px-4 py-2 rounded-full text-sm font-bold text-blue-600 shadow-sm">
					<?php td_icon( 'zap', 16, '', 'fill="currentColor"' ); ?>
					<span><?php td_e( 'hero_badge' ); ?></span>
				</div>
			<?php endif; ?>
			<h1 class="text-5xl md:text-7xl font-black tracking-tight leading-[1.1] text-slate-900">
				<?php td_e( 'hero_title' ); ?> <?php echo td_gradient( td_opt( 'hero_highlight' ) ); // phpcs:ignore ?>
			</h1>
			<p class="text-lg text-slate-600 max-w-xl mx-auto lg:mx-0"><?php td_e( 'hero_text' ); ?></p>
			<div class="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
				<?php if ( td_opt( 'hero_btn1_text' ) ) : ?>
					<a href="<?php echo esc_url( td_link( td_opt( 'hero_btn1_url' ) ) ); ?>" class="px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold text-lg hover:bg-blue-600 transition-all shadow-xl flex items-center justify-center group">
						<?php td_e( 'hero_btn1_text' ); ?> <?php td_icon( 'arrow-right', 24, 'ml-2 group-hover:translate-x-1 transition-transform' ); ?>
					</a>
				<?php endif; ?>
				<?php if ( td_opt( 'hero_btn2_text' ) ) : ?>
					<a href="<?php echo esc_url( td_link( td_opt( 'hero_btn2_url' ) ) ); ?>" class="px-8 py-4 bg-white text-slate-900 border border-slate-200 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all flex items-center justify-center"><?php td_e( 'hero_btn2_text' ); ?></a>
				<?php endif; ?>
			</div>
		</div>

		<div class="relative hidden lg:block" aria-hidden="true">
			<div class="relative z-10 animate-float">
				<div class="bg-white/40 backdrop-blur-xl border border-white/50 p-8 rounded-[3rem] shadow-2xl">
					<div class="grid grid-cols-2 gap-4">
						<div class="h-40 bg-gradient-to-br from-blue-500 to-blue-700 rounded-3xl flex items-center justify-center text-white shadow-lg shadow-blue-200"><?php td_icon( $tiles[0], 48 ); ?></div>
						<div class="h-40 bg-slate-900 rounded-3xl flex items-center justify-center text-white shadow-lg"><?php td_icon( $tiles[1], 48 ); ?></div>
						<div class="h-40 bg-slate-100 rounded-3xl flex items-center justify-center text-slate-400"><?php td_icon( $tiles[2], 48 ); ?></div>
						<div class="h-40 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-lg shadow-purple-200"><?php td_icon( $tiles[3], 48 ); ?></div>
					</div>
				</div>
			</div>
			<div class="absolute -top-10 -right-10 w-40 h-40 bg-blue-400/30 rounded-full blur-3xl"></div>
			<div class="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-400/30 rounded-full blur-3xl"></div>
		</div>
	</div>
</section>

<?php
$words = td_csv( td_opt( 'home_marquee' ) );
if ( td_opt( 'show_marquee' ) && $words ) :
	?>
	<div class="py-10 bg-slate-50 border-y border-slate-100 overflow-hidden" aria-hidden="true">
		<div class="td-marquee flex whitespace-nowrap items-center w-max">
			<?php for ( $i = 0; $i < 2; $i++ ) : foreach ( $words as $w ) : ?>
				<span class="text-slate-400 font-bold text-xl uppercase tracking-widest mr-12"><?php echo esc_html( $w ); ?></span>
			<?php endforeach; endfor; ?>
		</div>
	</div>
<?php endif; ?>
