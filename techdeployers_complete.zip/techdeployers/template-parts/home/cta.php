<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<section class="py-24 bg-white">
	<div class="max-w-5xl mx-auto px-4 text-center">
		<div class="td-reveal bg-gradient-to-br from-blue-600 to-indigo-700 p-10 md:p-16 rounded-[3rem] shadow-2xl relative overflow-hidden">
			<div class="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" aria-hidden="true"></div>
			<h2 class="text-4xl md:text-5xl font-bold text-white mb-8 relative z-10"><?php td_e( 'cta_title' ); ?></h2>
			<a href="<?php echo esc_url( td_link( td_opt( 'cta_btn_url' ) ) ); ?>" class="inline-block px-12 py-5 bg-white text-blue-600 rounded-2xl font-black text-xl hover:scale-105 transition-transform shadow-xl relative z-10"><?php td_e( 'cta_btn_text' ); ?></a>
		</div>
	</div>
</section>
