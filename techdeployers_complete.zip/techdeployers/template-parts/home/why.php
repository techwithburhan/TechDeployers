<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$features = td_lines( td_opt( 'why_features' ), 3 );
$stats    = array_pad( td_lines( td_opt( 'why_stats' ), 2 ), 4, array( '', '' ) );
?>
<section class="py-24 bg-slate-900 text-white relative overflow-hidden">
	<div class="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none" aria-hidden="true">
		<div class="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full blur-[120px]"></div>
		<div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-[120px]"></div>
	</div>
	<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
		<div class="grid lg:grid-cols-2 gap-20 items-center">
			<div class="td-reveal space-y-8">
				<h2 class="text-4xl md:text-5xl font-bold leading-tight"><?php td_e( 'why_title' ); ?> <br><span class="text-blue-400"><?php td_e( 'why_highlight' ); ?></span></h2>
				<div class="space-y-6">
					<?php foreach ( $features as $f ) : ?>
						<div class="flex items-start space-x-4">
							<div class="flex-shrink-0 w-12 h-12 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center text-blue-400"><?php td_icon( $f[0], 24 ); ?></div>
							<div>
								<h4 class="text-xl font-bold"><?php echo esc_html( $f[1] ); ?></h4>
								<p class="text-slate-400"><?php echo esc_html( $f[2] ); ?></p>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="td-reveal grid grid-cols-2 gap-6">
				<div class="space-y-6">
					<div class="bg-white/5 backdrop-blur-lg p-8 rounded-[2rem] border border-white/10 text-center">
						<div class="text-4xl font-black text-blue-400 mb-2"><?php echo esc_html( $stats[0][0] ); ?></div>
						<div class="text-sm text-slate-400 uppercase font-bold"><?php echo esc_html( $stats[0][1] ); ?></div>
					</div>
					<div class="bg-blue-600 p-8 rounded-[2rem] text-center shadow-xl shadow-blue-900/20">
						<div class="text-4xl font-black text-white mb-2"><?php echo esc_html( $stats[1][0] ); ?></div>
						<div class="text-sm text-blue-100 uppercase font-bold"><?php echo esc_html( $stats[1][1] ); ?></div>
					</div>
				</div>
				<div class="space-y-6 pt-12">
					<div class="bg-white/5 backdrop-blur-lg p-8 rounded-[2rem] border border-white/10 text-center">
						<div class="text-4xl font-black text-purple-400 mb-2"><?php echo esc_html( $stats[2][0] ); ?></div>
						<div class="text-sm text-slate-400 uppercase font-bold"><?php echo esc_html( $stats[2][1] ); ?></div>
					</div>
					<div class="bg-slate-800 p-8 rounded-[2rem] text-center border border-slate-700">
						<div class="text-4xl font-black text-white mb-2"><?php echo esc_html( $stats[3][0] ); ?></div>
						<div class="text-sm text-slate-400 uppercase font-bold"><?php echo esc_html( $stats[3][1] ); ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
