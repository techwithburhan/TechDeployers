<?php
/**
 * VideoTestimonials.tsx — 3-card carousel on desktop, single card on mobile.
 * Cards are rendered once into hidden <template>s; assets/js/main.js rotates them.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$items = td_get_items( 'td_testimonial' );
if ( ! $items ) {
	return;
}

if ( ! function_exists( 'td_video_card' ) ) {
	function td_video_card( $post ) {
		$id      = $post->ID;
		$name    = get_the_title( $post );
		$video   = td_youtube_id( get_post_meta( $id, '_td_video', true ) );
		$rating  = max( 1, min( 5, (int) get_post_meta( $id, '_td_rating', true ) ? (int) get_post_meta( $id, '_td_rating', true ) : 5 ) );
		$avatar  = has_post_thumbnail( $id ) ? get_the_post_thumbnail_url( $id, 'thumbnail' ) : get_post_meta( $id, '_td_avatar', true );
		$tag     = get_post_meta( $id, '_td_tag', true );
		$company = get_post_meta( $id, '_td_company', true );
		?>
		<div class="td-vcard relative w-full rounded-3xl overflow-hidden shadow-2xl flex flex-col transition-all duration-500 opacity-100 scale-100" style="background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%)">
			<?php if ( $tag ) : ?>
				<div class="absolute top-4 left-4 z-20"><span class="<?php echo esc_attr( td_color( get_post_meta( $id, '_td_tag_color', true ), 'solid' ) ); ?> text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-lg"><?php echo esc_html( $tag ); ?></span></div>
			<?php endif; ?>

			<div class="td-vmedia relative w-full" style="aspect-ratio:16/10" data-video="<?php echo esc_attr( $video ); ?>" data-title="<?php echo esc_attr( $name ); ?>">
				<?php if ( $video ) : ?>
					<img src="https://img.youtube.com/vi/<?php echo esc_attr( $video ); ?>/maxresdefault.jpg" alt="<?php echo esc_attr( $name ); ?>" loading="lazy" class="absolute inset-0 w-full h-full object-cover" onerror="if(this.src.indexOf('hqdefault')<0){this.src='https://img.youtube.com/vi/<?php echo esc_attr( $video ); ?>/hqdefault.jpg'}">
				<?php endif; ?>
				<div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent"></div>
				<div class="absolute inset-0 bg-gradient-to-r from-slate-950/30 via-transparent to-slate-950/30"></div>
				<div class="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
				<div class="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl pointer-events-none"></div>
				<?php if ( $video ) : ?>
					<button type="button" class="td-play absolute inset-0 flex items-center justify-center group" aria-label="<?php esc_attr_e( 'Play testimonial video', 'techdeployers' ); ?>">
						<span class="relative flex items-center justify-center">
							<span class="absolute w-24 h-24 rounded-full bg-white/10 animate-ping"></span>
							<span class="absolute w-20 h-20 rounded-full bg-white/20 border border-white/30"></span>
							<span class="relative w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:bg-blue-500 transition-all duration-300">
								<svg class="w-6 h-6 text-slate-900 group-hover:text-white transition-colors ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
							</span>
						</span>
						<span class="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-md border border-white/20 text-white text-xs font-semibold px-4 py-1.5 rounded-full tracking-wide"><?php esc_html_e( 'Watch Review', 'techdeployers' ); ?></span>
					</button>
				<?php endif; ?>
			</div>

			<div class="relative px-5 py-5 flex flex-col gap-3 bg-gradient-to-b from-slate-900 to-slate-950 border-t border-white/5">
				<div class="flex items-center justify-between">
					<div class="flex gap-0.5 text-yellow-400" aria-label="<?php echo esc_attr( $rating . '/5' ); ?>">
						<?php for ( $i = 0; $i < $rating; $i++ ) { td_icon( 'star', 14, '', 'fill="currentColor"' ); } ?>
					</div>
					<?php td_icon( 'quote', 18, 'text-blue-400/60' ); ?>
				</div>
				<p class="text-slate-300 text-sm leading-relaxed line-clamp-2 italic">&ldquo;<?php echo esc_html( get_post_meta( $id, '_td_quote', true ) ); ?>&rdquo;</p>
				<div class="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
				<div class="flex items-center gap-3">
					<div class="relative shrink-0">
						<?php if ( $avatar ) : ?>
							<img src="<?php echo esc_url( $avatar ); ?>" alt="<?php echo esc_attr( $name ); ?>" loading="lazy" class="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/60">
						<?php else : ?>
							<span class="w-10 h-10 rounded-full ring-2 ring-blue-500/60 bg-blue-600 text-white text-xs font-bold flex items-center justify-center"><?php echo esc_html( td_post_author_initials( $name ) ); ?></span>
						<?php endif; ?>
						<span class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-slate-900"></span>
					</div>
					<div class="flex-1 min-w-0">
						<p class="text-white font-bold text-sm leading-tight truncate"><?php echo esc_html( $name ); ?></p>
						<p class="text-blue-400 text-xs truncate"><?php echo esc_html( get_post_meta( $id, '_td_role', true ) ); ?></p>
					</div>
					<?php if ( $company ) : ?>
						<span class="shrink-0 text-[10px] text-slate-400 font-medium bg-white/5 border border-white/10 px-2 py-1 rounded-lg"><?php echo esc_html( $company ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}

$stats = td_lines( td_opt( 'testi_stats' ), 2 );
$count = count( $items );
?>
<section class="td-testimonials relative py-20 md:py-28 overflow-hidden" style="background:linear-gradient(180deg,#f8fafc 0%,#f1f5f9 50%,#f8fafc 100%)" data-count="<?php echo (int) $count; ?>">
	<div class="absolute inset-0 pointer-events-none" aria-hidden="true">
		<div class="absolute top-10 left-0 w-96 h-96 bg-blue-100/60 rounded-full blur-[120px]"></div>
		<div class="absolute bottom-10 right-0 w-96 h-96 bg-purple-100/60 rounded-full blur-[120px]"></div>
		<div class="absolute inset-0 opacity-[0.03]" style="background-image:radial-gradient(circle,#1e293b 1px,transparent 1px);background-size:28px 28px"></div>
	</div>

	<div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
		<div class="td-reveal text-center mb-14">
			<?php if ( td_opt( 'testi_badge' ) ) : ?>
				<div class="inline-flex items-center gap-2 bg-white border border-blue-100 shadow-sm px-4 py-2 rounded-full text-sm font-bold text-blue-600 mb-5"><span class="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span><?php td_e( 'testi_badge' ); ?></div>
			<?php endif; ?>
			<h2 class="text-4xl md:text-5xl font-black text-slate-900 leading-tight mb-4"><?php td_e( 'testi_title' ); ?> <?php echo td_gradient( td_opt( 'testi_highlight' ) ); // phpcs:ignore ?></h2>
			<p class="text-slate-500 text-lg max-w-2xl mx-auto leading-relaxed"><?php td_e( 'testi_text' ); ?></p>
			<?php if ( $stats ) : ?>
				<div class="flex flex-wrap justify-center gap-6 mt-8">
					<?php foreach ( $stats as $s ) : ?>
						<div class="bg-white border border-slate-100 shadow-sm rounded-2xl px-6 py-3 text-center">
							<div class="text-2xl font-black text-slate-900"><?php echo esc_html( $s[0] ); ?></div>
							<div class="text-xs text-slate-500 font-medium uppercase tracking-wider"><?php echo esc_html( $s[1] ); ?></div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php foreach ( $items as $i => $item ) : ?>
			<template class="td-testi-src" data-index="<?php echo (int) $i; ?>"><?php td_video_card( $item ); ?></template>
		<?php endforeach; ?>

		<!-- Desktop: 3 cards -->
		<div class="td-reveal hidden md:block">
			<div class="relative flex items-center justify-center gap-4 lg:gap-6 min-h-[200px]">
				<?php if ( $count > 1 ) : ?>
					<button type="button" data-td-prev class="absolute left-0 z-30 w-12 h-12 rounded-full bg-white border border-slate-200 shadow-lg flex items-center justify-center hover:bg-blue-600 hover:border-blue-600 hover:text-white text-slate-700 transition-all duration-300" aria-label="<?php esc_attr_e( 'Previous', 'techdeployers' ); ?>"><?php td_icon( 'chevron-left', 22 ); ?></button>
					<div class="w-[280px] lg:w-[310px] shrink-0 cursor-pointer" data-td-slot="left" data-td-prev></div>
				<?php endif; ?>
				<div class="w-[340px] lg:w-[400px] shrink-0 z-10 relative">
					<div class="absolute -inset-2 rounded-3xl bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 opacity-30 blur-xl pointer-events-none"></div>
					<div class="relative ring-2 ring-blue-500/40 rounded-3xl" data-td-slot="center"></div>
				</div>
				<?php if ( $count > 1 ) : ?>
					<div class="w-[280px] lg:w-[310px] shrink-0 cursor-pointer" data-td-slot="right" data-td-next></div>
					<button type="button" data-td-next class="absolute right-0 z-30 w-12 h-12 rounded-full bg-white border border-slate-200 shadow-lg flex items-center justify-center hover:bg-blue-600 hover:border-blue-600 hover:text-white text-slate-700 transition-all duration-300" aria-label="<?php esc_attr_e( 'Next', 'techdeployers' ); ?>"><?php td_icon( 'chevron-right', 22 ); ?></button>
				<?php endif; ?>
			</div>
		</div>

		<!-- Mobile: 1 card -->
		<div class="td-reveal md:hidden">
			<div class="relative mx-auto max-w-sm">
				<div class="absolute -inset-2 rounded-3xl bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 opacity-20 blur-xl pointer-events-none"></div>
				<div class="relative ring-2 ring-blue-500/30 rounded-3xl" data-td-slot="mobile"></div>
			</div>
			<?php if ( $count > 1 ) : ?>
				<div class="flex justify-center gap-4 mt-6">
					<button type="button" data-td-prev class="w-11 h-11 rounded-full bg-white border border-slate-200 shadow-md flex items-center justify-center hover:bg-blue-600 hover:text-white text-slate-700 transition-all" aria-label="<?php esc_attr_e( 'Previous', 'techdeployers' ); ?>"><?php td_icon( 'chevron-left', 20 ); ?></button>
					<button type="button" data-td-next class="w-11 h-11 rounded-full bg-white border border-slate-200 shadow-md flex items-center justify-center hover:bg-blue-600 hover:text-white text-slate-700 transition-all" aria-label="<?php esc_attr_e( 'Next', 'techdeployers' ); ?>"><?php td_icon( 'chevron-right', 20 ); ?></button>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $count > 1 ) : ?>
			<div class="flex justify-center gap-2 mt-8">
				<?php for ( $i = 0; $i < $count; $i++ ) : ?>
					<button type="button" data-td-dot="<?php echo (int) $i; ?>" class="td-dot rounded-full transition-all duration-300 w-2.5 h-2.5 bg-slate-300 hover:bg-slate-400" aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'techdeployers' ), $i + 1 ) ); ?>"></button>
				<?php endfor; ?>
			</div>
			<div class="mt-4 max-w-xs mx-auto h-0.5 bg-slate-200 rounded-full overflow-hidden">
				<div class="td-progress h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full" style="width:0"></div>
			</div>
		<?php endif; ?>
	</div>
</section>
