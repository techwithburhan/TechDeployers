<?php
/**
 * Capabilities.tsx — cards come from Admin → Capabilities.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$groups = td_capability_groups();
$sets   = array();
foreach ( $groups as $g ) {
	$sets[] = array( 'name' => $g->name, 'items' => td_get_items( 'td_capability', array( 'tax_query' => array( array( 'taxonomy' => 'td_cap_group', 'terms' => $g->term_id ) ) ) ) );
}
if ( ! $sets ) {
	$all = td_get_items( 'td_capability' );
	if ( $all ) {
		$sets[] = array( 'name' => '', 'items' => $all );
	}
}
if ( ! $sets ) {
	return;
}
?>
<section class="py-24 bg-slate-50/50">
	<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
		<div class="td-reveal flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
			<div class="max-w-2xl">
				<?php if ( td_opt( 'cap_badge' ) ) : ?>
					<div class="inline-flex items-center space-x-2 text-blue-600 font-bold text-sm uppercase tracking-widest mb-4"><?php td_icon( 'sparkles', 16 ); ?><span><?php td_e( 'cap_badge' ); ?></span></div>
				<?php endif; ?>
				<h2 class="text-4xl md:text-5xl font-black text-slate-900 leading-tight"><?php td_e( 'cap_title' ); ?> <br><?php echo td_gradient( td_opt( 'cap_highlight' ) ); // phpcs:ignore ?></h2>
			</div>
			<p class="text-slate-500 text-lg max-w-xs"><?php td_e( 'cap_text' ); ?></p>
		</div>

		<div class="space-y-24">
			<?php foreach ( $sets as $set ) : ?>
				<div class="space-y-10">
					<?php if ( $set['name'] ) : ?>
						<div class="flex items-center gap-4">
							<h3 class="text-2xl font-bold text-slate-800 whitespace-nowrap"><?php echo esc_html( $set['name'] ); ?></h3>
							<div class="h-[1px] w-full bg-slate-200"></div>
						</div>
					<?php endif; ?>
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
						<?php
						foreach ( $set['items'] as $item ) :
							$color = get_post_meta( $item->ID, '_td_color', true );
							$link  = get_post_meta( $item->ID, '_td_link', true );
							$tag   = $link ? 'a' : 'div';
							?>
							<<?php echo $tag; // phpcs:ignore ?> <?php echo $link ? 'href="' . esc_url( td_link( $link ) ) . '"' : ''; ?> class="td-reveal group relative block p-8 rounded-[2.5rem] bg-white border border-slate-100 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl <?php echo esc_attr( td_color( $color, 'hover' ) ); ?>">
								<div class="w-14 h-14 <?php echo esc_attr( td_color( $color, 'soft' ) . ' ' . td_color( $color, 'icon' ) ); ?> rounded-2xl flex items-center justify-center mb-8 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3">
									<?php td_icon( get_post_meta( $item->ID, '_td_icon', true ), 24 ); ?>
								</div>
								<div class="space-y-3">
									<div class="flex items-center justify-between">
										<h4 class="text-xl font-bold text-slate-900"><?php echo esc_html( get_the_title( $item ) ); ?></h4>
										<?php td_icon( 'arrow-up-right', 18, 'text-slate-300 group-hover:text-blue-500 transition-colors' ); ?>
									</div>
									<p class="text-slate-600 text-sm leading-relaxed"><?php echo esc_html( get_post_meta( $item->ID, '_td_desc', true ) ); ?></p>
								</div>
								<div class="absolute inset-0 rounded-[2.5rem] opacity-0 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none <?php echo esc_attr( td_color( $color, 'soft' ) ); ?>"></div>
							</<?php echo $tag; // phpcs:ignore ?>>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
