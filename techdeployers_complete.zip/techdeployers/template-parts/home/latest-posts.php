<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$q = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) );
if ( ! $q->have_posts() ) {
	return;
}
?>
<section class="py-24 bg-white">
	<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
		<div class="td-reveal flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
			<div>
				<?php if ( td_opt( 'hblog_badge' ) ) : ?><p class="text-blue-600 font-bold uppercase tracking-widest text-sm mb-2"><?php td_e( 'hblog_badge' ); ?></p><?php endif; ?>
				<h2 class="text-3xl md:text-5xl font-black text-slate-900 leading-tight"><?php td_e( 'hblog_title' ); ?><br><?php echo td_gradient( td_opt( 'hblog_highlight' ) ); // phpcs:ignore ?></h2>
			</div>
			<a href="<?php echo esc_url( td_blog_url() ); ?>" class="inline-flex items-center gap-2 px-6 py-3 border-2 border-slate-900 text-slate-900 rounded-2xl font-bold hover:bg-slate-900 hover:text-white transition-all shrink-0">
				<?php td_e( 'hblog_btn' ); ?> <?php td_icon( 'arrow-right', 18 ); ?>
			</a>
		</div>
		<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
			<?php
			while ( $q->have_posts() ) :
				$q->the_post();
				get_template_part( 'template-parts/components/post-card', null, array( 'variant' => 'home' ) );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
