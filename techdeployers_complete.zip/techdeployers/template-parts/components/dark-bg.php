<?php
/**
 * Decorative blobs + grid used behind the dark page heroes. $args['id'] = unique pattern id, $args['blobs'] = 'blog'|'animated'.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$pid  = isset( $args['id'] ) ? $args['id'] : 'td-grid';
$mode = isset( $args['blobs'] ) ? $args['blobs'] : 'blog';
?>
<div class="absolute inset-0 -z-10" aria-hidden="true">
	<?php if ( 'animated' === $mode ) : ?>
		<div class="td-blob-1 absolute left-0 top-12 h-64 w-64 rounded-full bg-blue-500/30 blur-3xl"></div>
		<div class="td-blob-2 absolute right-0 top-20 h-72 w-72 rounded-full bg-purple-500/30 blur-3xl"></div>
		<div class="td-blob-3 absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-cyan-500/20 blur-3xl"></div>
	<?php else : ?>
		<div class="absolute top-10 left-10 w-72 h-72 rounded-full bg-blue-500/20 blur-3xl"></div>
		<div class="absolute bottom-0 right-10 w-80 h-80 rounded-full bg-purple-500/20 blur-3xl"></div>
	<?php endif; ?>
</div>
<svg class="absolute inset-0 -z-10 h-full w-full stroke-white/[0.05] [mask-image:radial-gradient(ellipse_at_center,white,transparent_75%)]" aria-hidden="true">
	<defs><pattern id="<?php echo esc_attr( $pid ); ?>" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M.5 60V.5H60" fill="none"/></pattern></defs>
	<rect width="100%" height="100%" fill="url(#<?php echo esc_attr( $pid ); ?>)"/>
</svg>
