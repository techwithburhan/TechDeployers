<?php
/**
 * Blog post card. $args['variant']: home | grid | featured | related
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$variant = isset( $args['variant'] ) ? $args['variant'] : 'grid';
$cat     = td_post_category();
$author  = td_post_author();
$read    = td_read_time();
$short   = get_the_date( 'F j' );
$title   = get_the_title();
$excerpt = get_the_excerpt();
$search  = strtolower( wp_strip_all_tags( $title . ' ' . $excerpt ) );

if ( 'featured' === $variant ) : ?>
	<a href="<?php the_permalink(); ?>" class="td-reveal group relative rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 bg-white">
		<div class="relative h-52 overflow-hidden">
			<img src="<?php echo esc_url( td_cover_url() ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
			<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/40 to-transparent"></div>
			<?php if ( $cat['name'] ) : ?><span class="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-bold <?php echo esc_attr( $cat['class'] ); ?>"><?php echo esc_html( $cat['name'] ); ?></span><?php endif; ?>
		</div>
		<div class="bg-white p-6">
			<h3 class="font-bold text-slate-900 text-lg leading-snug mb-2 group-hover:text-blue-600 transition-colors line-clamp-2"><?php echo esc_html( $title ); ?></h3>
			<p class="text-slate-500 text-sm line-clamp-2 mb-4"><?php echo esc_html( $excerpt ); ?></p>
			<div class="flex items-center justify-between text-xs text-slate-400">
				<div class="flex items-center gap-3">
					<div class="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-[10px]"><?php echo esc_html( $author['initials'] ); ?></div>
					<span class="font-medium text-slate-600"><?php echo esc_html( $author['name'] ); ?></span>
				</div>
				<div class="flex items-center gap-1"><?php td_icon( 'clock', 12 ); ?><?php echo esc_html( $read ); ?></div>
			</div>
		</div>
	</a>

<?php elseif ( 'related' === $variant ) : ?>
	<a href="<?php the_permalink(); ?>" class="td-reveal group bg-slate-50 rounded-3xl overflow-hidden border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all duration-500">
		<div class="relative h-44 overflow-hidden">
			<img src="<?php echo esc_url( td_cover_url() ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
			<div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
			<?php if ( $cat['name'] ) : ?><span class="absolute bottom-3 left-4 px-3 py-1 rounded-full text-xs font-bold <?php echo esc_attr( $cat['class'] ); ?>"><?php echo esc_html( $cat['name'] ); ?></span><?php endif; ?>
		</div>
		<div class="p-5">
			<h3 class="font-bold text-slate-900 leading-snug mb-2 group-hover:text-blue-600 transition-colors line-clamp-2"><?php echo esc_html( $title ); ?></h3>
			<p class="text-slate-500 text-sm line-clamp-2"><?php echo esc_html( $excerpt ); ?></p>
			<div class="flex items-center gap-2 mt-4 text-xs text-slate-400">
				<?php td_icon( 'clock', 12 ); ?><?php echo esc_html( $read ); ?><span>·</span><?php echo esc_html( $short ); ?>
			</div>
		</div>
	</a>

<?php else :
	$is_grid = 'grid' === $variant;
	?>
	<a href="<?php the_permalink(); ?>" data-search="<?php echo esc_attr( $search ); ?>" class="td-reveal td-post-card group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-slate-100 <?php echo $is_grid ? 'hover:border-blue-100' : 'hover:border-blue-200'; ?> transition-all duration-500 flex flex-col">
		<div class="relative h-48 overflow-hidden">
			<img src="<?php echo esc_url( td_cover_url() ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
			<div class="absolute inset-0 bg-gradient-to-t <?php echo $is_grid ? 'from-black/50' : 'from-black/60'; ?> to-transparent"></div>
			<?php if ( $cat['name'] ) : ?><span class="absolute bottom-3 left-4 px-3 py-1 rounded-full text-xs font-bold <?php echo esc_attr( $cat['class'] ); ?>"><?php echo esc_html( $cat['name'] ); ?></span><?php endif; ?>
		</div>
		<div class="p-6 flex flex-col flex-1">
			<h3 class="font-bold text-slate-900 text-lg leading-snug <?php echo $is_grid ? 'mb-3' : 'mb-2'; ?> group-hover:text-blue-600 transition-colors line-clamp-2"><?php echo esc_html( $title ); ?></h3>
			<p class="text-slate-500 text-sm leading-relaxed <?php echo $is_grid ? 'line-clamp-3' : 'line-clamp-2'; ?> flex-1 mb-4"><?php echo esc_html( $excerpt ); ?></p>
			<?php
			if ( $is_grid ) :
				$tags = get_the_tags();
				if ( $tags ) :
					?>
					<div class="flex flex-wrap gap-2 mb-4">
						<?php foreach ( array_slice( $tags, 0, 2 ) as $tag ) : ?>
							<span class="px-2 py-1 bg-slate-100 text-slate-500 text-xs rounded-lg">#<?php echo esc_html( $tag->name ); ?></span>
						<?php endforeach; ?>
					</div>
					<?php
				endif;
			endif;
			?>
			<div class="flex items-center justify-between pt-4 border-t border-slate-100">
				<div class="flex items-center gap-2">
					<div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-xs"><?php echo esc_html( $author['initials'] ); ?></div>
					<div>
						<p class="text-xs font-semibold text-slate-700"><?php echo esc_html( $author['name'] ); ?></p>
						<?php if ( $is_grid && $author['role'] ) : ?><p class="text-[10px] text-slate-400"><?php echo esc_html( $author['role'] ); ?></p><?php endif; ?>
					</div>
				</div>
				<div class="flex items-center gap-3 text-xs text-slate-400">
					<div class="flex items-center gap-1"><?php td_icon( 'calendar', 11 ); ?><?php echo esc_html( $short ); ?></div>
					<div class="flex items-center gap-1"><?php td_icon( 'clock', 11 ); ?><?php echo esc_html( $read ); ?></div>
				</div>
			</div>
		</div>
	</a>
<?php endif;
