<?php
/**
 * Blue gradient CTA band used on blog pages. $args: title, text, btn, url
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<section class="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
	<div class="max-w-4xl mx-auto px-4 text-center">
		<h2 class="text-3xl md:text-4xl font-bold text-white mb-4"><?php echo esc_html( $args['title'] ); ?></h2>
		<?php if ( ! empty( $args['text'] ) ) : ?><p class="text-white/80 mb-8 text-lg"><?php echo esc_html( $args['text'] ); ?></p><?php endif; ?>
		<a href="<?php echo esc_url( isset( $args['url'] ) ? $args['url'] : td_contact_url() ); ?>" class="inline-flex items-center gap-2 px-8 py-4 bg-white text-blue-600 rounded-2xl font-bold hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
			<?php echo esc_html( isset( $args['btn'] ) ? $args['btn'] : __( 'Get a Free Consultation', 'techdeployers' ) ); ?>
			<?php td_icon( 'arrow-right', 18 ); ?>
		</a>
	</div>
</section>
