<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<section class="relative isolate min-h-[70vh] flex items-center bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 pt-32 pb-20 overflow-hidden">
	<?php get_template_part( 'template-parts/components/dark-bg', null, array( 'id' => 'td-404-grid' ) ); ?>
	<div class="max-w-3xl mx-auto px-4 text-center">
		<p class="text-7xl md:text-9xl font-black bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">404</p>
		<h1 class="text-3xl md:text-4xl font-bold text-white mb-4"><?php esc_html_e( 'Page not found', 'techdeployers' ); ?></h1>
		<p class="text-slate-300 mb-10"><?php esc_html_e( 'The page you are looking for has moved or no longer exists.', 'techdeployers' ); ?></p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="inline-flex items-center gap-2 px-8 py-4 bg-white text-blue-600 rounded-2xl font-bold hover:shadow-xl hover:-translate-y-1 transition-all"><?php td_icon( 'arrow-left', 18 ); ?> <?php esc_html_e( 'Back to Home', 'techdeployers' ); ?></a>
	</div>
</section>
<?php
get_footer();
